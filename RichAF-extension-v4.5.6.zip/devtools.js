chrome.devtools.panels.create(
  "RichAF",
  "icons/icon16.png",
  "panel.html",
  function (panel) {
    // Panel created successfully
    console.log("RichAF panel created");
  }
);
