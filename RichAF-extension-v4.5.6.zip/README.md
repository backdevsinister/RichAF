# RichAF 4.2

RichAF is a dark Chrome DevTools workspace with a Sources-style resource tree, network inspection helpers, live DOM/CSS tools, JSON tools, a background customizer, and an optional local Node.js backend.

## Extension

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this `RichAF-extension` folder.
5. Open DevTools and choose **RichAF**.

## Optional backend

The backend is in `backend/`.

```bash
cd backend
npm install
npm start
```

Default: `http://127.0.0.1:3210`

The extension's **Server** tab automatically checks the backend and opens a WebSocket for real-time events. The backend stores settings/projects/events locally in JSON and stores uploaded background images under `backend/uploads/backgrounds`.

## Backgrounds

Settings supports a remote background URL or an image upload through the local backend, plus blur and dim controls.

## Notes

- SCSS is shown when a page actually exposes/loads an `.scss` resource. Browsers commonly receive compiled CSS instead.
- The backend is optional; RichAF's normal DevTools features still work when it is offline.
