@echo off
setlocal
cd /d "%~dp0backend"
echo.
echo RichAF Backend
echo ===============================
echo Installing/checking dependencies...
npm install
if errorlevel 1 (
  echo.
  echo npm install failed. Make sure Node.js 18+ is installed.
  pause
  exit /b 1
)
echo.
echo Starting RichAF backend on http://127.0.0.1:3210
echo Keep this window open while using RichAF.
echo.
npm start
pause
