(function () {
  "use strict";

  var currentStorage = "localStorage";
  var refreshTimer = null;
  var settings = { autoRefresh: 0, savedCss: "", outlineOnLoad: true, backendUrl: "http://127.0.0.1:3210", background: "", backgroundBlur: 0, backgroundDim: 25, font: "Arial", glass: true, animations: true };
  var netRequests = [];
  var selectedNet = null;
  var netTypeFilter = "all";
  var preserveLog = false;
  var netIdSeq = 0;
  var hostTree = {}; // host -> { paths: { path: [requests] } }
  var sourceResources = [];
  var sourceTabs = [];
  var activeSource = null;
  var sourceWrap = false;

  function escapeHtml(value) {
    return String(value == null ? "" : value).replace(/[&<>\"']/g, function (ch) {
      return ({"&":"&amp;","<":"&lt;",">":"&gt;",'\"':"&quot;", "'":"&#39;"})[ch];
    });
  }

  // Escape a value before embedding it inside a JavaScript single-quoted expression.
  function esc(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/'/g, "\\'")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\u2028/g, "\\u2028")
      .replace(/\u2029/g, "\\u2029");
  }

  // Evaluate JavaScript in the page currently inspected by Chrome DevTools.
  function evalPage(expression, callback) {
    callback = typeof callback === "function" ? callback : function () {};
    if (typeof chrome === "undefined" || !chrome.devtools || !chrome.devtools.inspectedWindow ||
        typeof chrome.devtools.inspectedWindow.eval !== "function") {
      callback(null, { isException: true, description: "RichAF must be opened as a Chrome DevTools panel." });
      return;
    }
    try {
      chrome.devtools.inspectedWindow.eval(String(expression), function (result, exceptionInfo) {
        var failed = exceptionInfo && (exceptionInfo.isException || exceptionInfo.isError || exceptionInfo.description || exceptionInfo.value);
        callback(result, failed ? exceptionInfo : null);
      });
    } catch (error) {
      callback(null, { isException: true, description: error && error.message ? error.message : String(error) });
    }
  }

  // Refresh the small DOM statistics shown by the Tools panel and Auto Refresh.
  function refreshPageInfo() {
    evalPage(
      "(function(){return{url:location.href,title:document.title||'',readyState:document.readyState,domNodes:document.querySelectorAll('*').length,scripts:document.scripts?document.scripts.length:0,stylesheets:document.styleSheets?document.styleSheets.length:0,links:document.querySelectorAll('link').length,images:document.images?document.images.length:0,iframes:document.querySelectorAll('iframe').length,bodyBytes:document.body&&document.body.innerHTML?document.body.innerHTML.length:0};})()",
      function (result, exceptionInfo) {
        var out = document.getElementById("tool-events");
        if (!out) return;
        if (exceptionInfo) {
          out.textContent = "DOM stats error: " + (exceptionInfo.description || exceptionInfo.value || "Unknown inspected-page error");
          return;
        }
        if (!result) {
          out.textContent = "DOM stats: no result.";
          return;
        }
        out.textContent = [
          "URL: " + (result.url || ""),
          "Title: " + (result.title || ""),
          "Ready: " + (result.readyState || ""),
          "DOM nodes: " + result.domNodes,
          "Scripts: " + result.scripts,
          "Stylesheets: " + result.stylesheets,
          "Link elements: " + result.links,
          "Images: " + result.images,
          "Iframes: " + result.iframes,
          "Body HTML size: " + result.bodyBytes + " chars"
        ].join("\n");
      }
    );
  }

  var views = {
    dashboard: { title: "Dashboard", subtitle: "totally normal overview nothing shady" },
    sources: { title: "Sources", subtitle: "inspect loaded documents, stylesheets, scripts, images and more" },
    editor: { title: "Live Edit", subtitle: "mutate the DOM while nobody is looking" },
    network: { title: "Network", subtitle: "sniff XHR / Fetch / whatever leaks out" },
    storage: { title: "Storage", subtitle: "localStorage is free real estate" },
    console: { title: "Console", subtitle: "eval whatever · no sandbox we ball" },
    css: { title: "CSS", subtitle: "inject styles into their page" },
    json: { title: "JSON", subtitle: "format · minify · yeet" },
    tools: { title: "Tools", subtitle: "little utilities for the workspace" },
    server: { title: "Server", subtitle: "talk to the optional RichAF local backend" },
    cloud: { title: "Cloud", subtitle: "persistent workspace files and folders" },
    settings: { title: "Settings", subtitle: "why are you still configuring this" }
  };

  // ── Local RichAF profile + startup animation ─────────────────
  // This profile is intentionally local-only; it is not a security boundary.
  var RICHAF_DEFAULT_USER = "Admin";
  var RICHAF_DEFAULT_PASSWORD = "admin123";

  function setInterfaceFont(font) {
    // RichAF is intentionally Arial-first. Other options are retained for compatibility,
    // but the default and all newly created profiles use Arial.
    var map = {
      "Arial": 'Arial, Helvetica, sans-serif',
      "system": 'Arial, Helvetica, sans-serif',
      "Inter": 'Arial, Helvetica, sans-serif',
      "Segoe UI": 'Arial, Helvetica, sans-serif',
      "Roboto": 'Arial, Helvetica, sans-serif',
      "Helvetica Neue": 'Arial, Helvetica, sans-serif',
      "JetBrains Mono": 'Arial, Helvetica, sans-serif',
      "monospace": 'Arial, Helvetica, sans-serif'
    };
    document.documentElement.style.setProperty("--richaf-font", map[font] || map.Arial);
  }

  function applyInterfacePreferences() {
    setInterfaceFont(settings.font || "Arial");
    document.body.classList.toggle("glass-off", settings.glass === false);
    document.body.classList.toggle("no-animations", settings.animations === false);
  }

  function getProfile() {
    try { return JSON.parse(localStorage.getItem("richaf_profile") || "null"); } catch (e) { return null; }
  }

  function saveProfile(profile) {
    localStorage.setItem("richaf_profile", JSON.stringify(profile));
  }

  function updateBrandProfile() {
    var profile = getProfile();
    var name = document.getElementById("brand-name");
    var avatar = document.getElementById("brand-avatar");
    if (!profile) return;
    if (name) name.textContent = profile.username || "RichAF";
    if (avatar) {
      if (profile.pfp) avatar.innerHTML = '<img src="' + String(profile.pfp).replace(/"/g, '&quot;') + '" alt="">';
      else avatar.textContent = String(profile.username || "R").slice(0,1).toUpperCase();
    }
  }

  function showKeyScreen() {
    var key = document.getElementById("key-screen");
    var profile = getProfile();
    var heading = document.getElementById("auth-heading");
    var subtitle = document.getElementById("auth-subtitle");
    var button = document.getElementById("key-login");
    var hint = document.getElementById("key-hint");
    var pfpRow = document.querySelector(".profile-avatar-row");
    var user = document.getElementById("key-username");
    var pass = document.getElementById("key-value");
    if (key) key.classList.remove("hidden");
    document.body.classList.remove("booting");
    if (profile) {
      heading.textContent = "Welcome back";
      subtitle.textContent = "Sign in to your local dev profile";
      button.textContent = "Sign in";
      hint.textContent = "Profile: " + (profile.username || RICHAF_DEFAULT_USER);
      if (pfpRow) pfpRow.style.display = "none";
      if (user) { user.value = profile.username || RICHAF_DEFAULT_USER; user.readOnly = true; }
      if (pass) { pass.autocomplete = "current-password"; pass.placeholder = "Enter your local password"; }
      if (profile.pfp) setProfileAvatar(profile.pfp);
    } else {
      heading.textContent = "Set up your local dev profile";
      subtitle.textContent = "Your profile stays on this browser";
      button.textContent = "Create local profile";
      hint.textContent = "Default local dev profile: Admin / admin123";
      if (pfpRow) pfpRow.style.display = "flex";
      if (user) { user.readOnly = false; user.value = RICHAF_DEFAULT_USER; }
      if (pass) { pass.autocomplete = "new-password"; pass.placeholder = "Create a local password"; }
    }
    setTimeout(function () { if (pass) pass.focus(); }, 80);
  }

  function setProfileAvatar(src) {
    var avatar = document.getElementById("profile-avatar");
    if (!avatar) return;
    if (src) avatar.innerHTML = '<img src="' + String(src).replace(/"/g, '&quot;') + '" alt="Profile picture">';
    else avatar.textContent = "ϟ";
  }

  function finishBoot() {
    var boot = document.getElementById("boot-screen");
    if (!boot) return;
    var authenticated = localStorage.getItem("richaf_authenticated") === "1" && getProfile();
    // Returning users should never wait through a fake loading sequence.
    if (authenticated) {
      boot.remove();
      var key = document.getElementById("key-screen");
      if (key) key.remove();
      document.body.classList.remove("booting");
      updateBrandProfile();
      return;
    }
    // First-run setup gets only a very short branded transition.
    boot.classList.add("fade-out");
    setTimeout(function () {
      boot.remove();
      showKeyScreen();
    }, 220);
  }

  function authenticate() {
    var profile = getProfile();
    var user = (document.getElementById("key-username").value || "").trim();
    var password = document.getElementById("key-value").value || "";
    var err = document.getElementById("key-error");
    var pfp = null;
    if (profile) {
      if (user === profile.username && password === profile.password) {
        localStorage.setItem("richaf_authenticated", "1");
        err.textContent = "";
        var screen = document.getElementById("key-screen");
        screen.classList.add("fade-out");
        setTimeout(function(){ screen.remove(); document.body.classList.remove("booting"); updateBrandProfile(); }, 500);
      } else {
        err.textContent = "Incorrect username or password.";
        var card = document.querySelector(".setup-glass");
        card.classList.remove("key-shake"); void card.offsetWidth; card.classList.add("key-shake");
      }
      return;
    }
    var input = document.getElementById("profile-pfp");
    if (input && input.files && input.files[0]) {
      var file = input.files[0];
      var reader = new FileReader();
      reader.onload = function(){ createProfile(user, password, reader.result, err); };
      reader.readAsDataURL(file);
    } else {
      createProfile(user, password, null, err);
    }
  }

  function createProfile(user, password, pfp, err) {
    user = user || RICHAF_DEFAULT_USER;
    password = password || RICHAF_DEFAULT_PASSWORD;
    if (user.length < 1 || password.length < 1) { err.textContent = "Username and password are required."; return; }
    saveProfile({ username:user, password:password, pfp:pfp || null, createdAt:Date.now() });
    localStorage.setItem("richaf_authenticated", "1");
    err.textContent = "Profile created.";
    var screen = document.getElementById("key-screen");
    screen.classList.add("fade-out");
    setTimeout(function(){ screen.remove(); document.body.classList.remove("booting"); updateBrandProfile(); }, 500);
  }

  document.getElementById("key-login").addEventListener("click", authenticate);
  document.getElementById("key-value").addEventListener("keydown", function(e){ if(e.key === "Enter") authenticate(); });
  document.getElementById("profile-pfp").addEventListener("change", function(){
    var f=this.files && this.files[0]; if(!f)return; var r=new FileReader(); r.onload=function(){setProfileAvatar(r.result);}; r.readAsDataURL(f);
  });
  document.getElementById("profile-pfp-clear").addEventListener("click", function(){ document.getElementById("profile-pfp").value=""; setProfileAvatar(null); });

  // ── Host / resource tree (Sources-style) ────────────────────
  function buildHostTreeFromPage() {
    // Collect hosts from performance resources + our network list
    evalPage(
      "(function(){" +
      "var hosts={};" +
      "try{" +
      "  var entries=performance.getEntriesByType('resource')||[];" +
      "  entries.forEach(function(e){" +
      "    try{" +
      "      var u=new URL(e.name);" +
      "      var h=u.hostname;" +
      "      if(!hosts[h])hosts[h]=[];" +
      "      hosts[h].push({url:e.name,path:u.pathname,type:e.initiatorType||'other',size:e.transferSize||0});" +
      "    }catch(x){}" +
      "  });" +
      "  try{ var loc=new URL(location.href); if(!hosts[loc.hostname])hosts[loc.hostname]=[]; hosts[loc.hostname].unshift({url:location.href,path:loc.pathname||'/',type:'doc',size:0}); }catch(x){}" +
      "}catch(e){}" +
      "return hosts;" +
      "})()",
      function (result) {
        if (!result || typeof result !== "object") return;
        // merge network requests into hosts
        netRequests.forEach(function (r) {
          try {
            var u = new URL(r.url);
            var h = u.hostname;
            if (!result[h]) result[h] = [];
            result[h].push({
              url: r.url,
              path: u.pathname + u.search,
              type: r.type || "other",
              size: r.size || 0,
              netId: r.id
            });
          } catch (e) {}
        });
        hostTree = result;
        renderTree(result);
      }
    );
  }

  function materialIcon(name) {
    return '<span class="material-symbols-rounded material-file-icon">' + name + '</span>';
  }

  function fileIcon(f) {
    var path = String(f.path || f.url || "").toLowerCase().split("?")[0];
    if (/\.scss$/.test(path)) return materialIcon("style");
    if (/\.sass$/.test(path)) return materialIcon("style");
    if (/\.html?$/.test(path)) return materialIcon("html");
    if (/\.css$/.test(path)) return materialIcon("css");
    if (/\.(js|mjs|cjs|ts|tsx)$/.test(path)) return materialIcon("javascript");
    if (/\.json$/.test(path)) return materialIcon("data_object");
    if (/\.(png|jpe?g|gif|webp|svg|avif|ico)$/.test(path)) return materialIcon("image");
    if (/\.(woff2?|ttf|otf|eot)$/.test(path)) return materialIcon("font_download");
    if (/\.(mp3|wav|ogg|mp4|webm|mov)$/.test(path)) return materialIcon("movie");
    if (f.type === "xhr" || f.type === "fetch") return materialIcon("bolt");
    if (f.type === "doc") return materialIcon("description");
    if (f.type === "script") return materialIcon("javascript");
    if (f.type === "stylesheet") return materialIcon("css");
    if (f.type === "image") return materialIcon("image");
    return materialIcon("insert_drive_file");
  }

  function activateNetworkForResource(f) {
    if (f.netId) {
      var found = netRequests.find(function (r) { return r.id === f.netId; });
      if (found) {
        document.querySelectorAll(".tab").forEach(function (t) { t.classList.toggle("active", t.dataset.view === "network"); });
        document.querySelectorAll(".view").forEach(function (v) { v.classList.remove("active"); });
        document.getElementById("view-network").classList.add("active");
        document.getElementById("view-title").textContent = views.network.title;
        document.getElementById("view-subtitle").textContent = views.network.subtitle;
        selectedNet = found;
        showNetDetail(found);
        renderNetList();
        return;
      }
    }
    document.getElementById("net-filter").value = f.url || f.path || "";
    document.querySelectorAll(".tab").forEach(function (t) { t.classList.toggle("active", t.dataset.view === "network"); });
    document.querySelectorAll(".view").forEach(function (v) { v.classList.remove("active"); });
    document.getElementById("view-network").classList.add("active");
    document.getElementById("view-title").textContent = views.network.title;
    document.getElementById("view-subtitle").textContent = views.network.subtitle;
    renderNetList();
  }

  function renderTree(hosts) {
    var box = document.getElementById("tree-hosts");
    var filter = (document.getElementById("tree-search").value || "").toLowerCase();
    var hostNames = Object.keys(hosts).sort();
    if (!hostNames.length) {
      box.innerHTML = '<div class="muted mono" style="padding:6px 8px;font-size:10px">no hosts yet</div>';
      return;
    }
    box.innerHTML = "";

    function addFolder(parent, name, depth) {
      var node = document.createElement("div");
      node.className = "tree-node open";
      node.innerHTML = '<div class="tree-row tree-folder"><span class="tree-twisty">▼</span><span class="tree-icon material-symbols-rounded">folder</span><span class="tree-label">' + escapeHtml(name) + '</span></div><div class="tree-children"></div>';
      node.querySelector(".tree-folder").addEventListener("click", function (e) {
        e.stopPropagation(); node.classList.toggle("open");
        node.querySelector(".tree-twisty").textContent = node.classList.contains("open") ? "▼" : "▶";
      });
      parent.appendChild(node);
      return node.querySelector(".tree-children");
    }

    hostNames.forEach(function (host) {
      var files = hosts[host] || [];
      var filtered = files.filter(function (f) {
        if (!filter) return true;
        return host.toLowerCase().indexOf(filter) !== -1 || String(f.path || "").toLowerCase().indexOf(filter) !== -1 || String(f.url || "").toLowerCase().indexOf(filter) !== -1;
      });
      if (!filtered.length) return;

      var hostNode = document.createElement("div");
      hostNode.className = "tree-node open";
      hostNode.innerHTML = '<div class="tree-row tree-host"><span class="tree-twisty">▼</span><span class="tree-icon material-symbols-rounded">language</span><span class="tree-label">' + escapeHtml(host) + '</span></div><div class="tree-children"></div>';
      var hostChildren = hostNode.querySelector(".tree-children");
      hostNode.querySelector(".tree-host").addEventListener("click", function (e) {
        e.stopPropagation(); hostNode.classList.toggle("open");
        hostNode.querySelector(".tree-twisty").textContent = hostNode.classList.contains("open") ? "▼" : "▶";
      });

      var root = { children: {}, files: [] };
      var seen = {};
      filtered.forEach(function (f) {
        var key = f.path || f.url;
        if (seen[key]) return;
        seen[key] = true;
        var clean = String(key || "/").split("?")[0];
        var parts = clean.split("/").filter(Boolean);
        var file = parts.pop() || "/";
        var cursor = root;
        parts.forEach(function (part) {
          cursor.children[part] = cursor.children[part] || { children: {}, files: [] };
          cursor = cursor.children[part];
        });
        cursor.files.push(Object.assign({}, f, { displayName: file }));
      });

      function renderBranch(parent, branch) {
        Object.keys(branch.children).sort().forEach(function (folder) {
          var child = addFolder(parent, folder);
          renderBranch(child, branch.children[folder]);
        });
        branch.files.sort(function (a,b) { return (a.displayName || "").localeCompare(b.displayName || ""); }).forEach(function (f) {
          var row = document.createElement("div");
          row.className = "tree-row tree-file";
          row.title = f.url || f.path || "";
          row.innerHTML = '<span class="tree-twisty"></span><span class="tree-icon">' + fileIcon(f) + '</span><span class="tree-label">' + escapeHtml(f.displayName || f.path || f.url) + '</span>';
          row.addEventListener("click", function (e) {
            e.stopPropagation();
            document.querySelectorAll(".tree-row.active").forEach(function (r) { r.classList.remove("active"); });
            row.classList.add("active");
            if (f.__resource) {
              openSourceResource(f.__resource);
            } else {
              activateNetworkForResource(f);
            }
          });
          parent.appendChild(row);
        });
      }

      renderBranch(hostChildren, root);
      box.appendChild(hostNode);
    });
  }

  // ── Sources workspace ───────────────────────────────────────
  function sourceKind(resource) {
    var url = String(resource && resource.url || "").toLowerCase().split("?")[0];
    if (/\.(html?|xhtml)$/.test(url)) return "HTML";
    if (/\.(css|scss|sass|less)$/.test(url)) return /\.scss$/.test(url) ? "SCSS" : "CSS";
    if (/\.(m?js|cjs|ts|tsx|jsx)$/.test(url)) return "JS";
    if (/\.json$/.test(url)) return "JSON";
    if (/\.(png|jpe?g|gif|webp|avif|svg|ico)$/.test(url)) return "IMAGE";
    if (/\.(woff2?|ttf|otf|eot)$/.test(url)) return "FONT";
    return String(resource && resource.type || "RESOURCE").toUpperCase();
  }

  function sourceFileName(url) {
    try {
      var u = new URL(url);
      var path = u.pathname || "/";
      var bits = path.split("/").filter(Boolean);
      return bits.pop() || u.hostname || url;
    } catch (e) {
      var bits2 = String(url || "").split("/").filter(Boolean);
      return bits2.pop() || String(url || "resource");
    }
  }

  function switchToView(view) {
    document.querySelectorAll(".tab").forEach(function (t) { t.classList.toggle("active", t.dataset.view === view); });
    document.querySelectorAll(".view").forEach(function (v) { v.classList.remove("active"); });
    var el = document.getElementById("view-" + view);
    if (el) el.classList.add("active");
    if (views[view]) {
      document.getElementById("view-title").textContent = views[view].title;
      document.getElementById("view-subtitle").textContent = views[view].subtitle;
    }
  }

  // Top navigation: every tab must explicitly switch the workspace view.
  // Keep this delegated so tabs remain clickable even if the header is re-rendered.
  document.querySelector(".tabs").addEventListener("click", function (event) {
    var tab = event.target.closest(".tab");
    if (!tab || !this.contains(tab)) return;
    event.preventDefault();
    event.stopPropagation();
    var view = tab.dataset.view;
    if (!view || !views[view]) return;
    switchToView(view);
    if (view === "sources") loadRealSources();
    if (view === "tools") refreshPageInfo();
    if (view === "network") renderNetList();
    if (view === "storage") { loadStorage(currentStorage); loadCookies(); }
    if (view === "cloud") cloudList();
  });

  function renderSourceTabs() {
    var box = document.getElementById("source-tabs");
    if (!box) return;
    box.innerHTML = "";
    if (!sourceTabs.length) {
      box.innerHTML = '<div class="source-empty">Select a resource from the tree.</div>';
      return;
    }
    sourceTabs.forEach(function (resource, index) {
      var tab = document.createElement("button");
      tab.className = "source-tab" + (activeSource && activeSource.url === resource.url ? " active" : "");
      tab.innerHTML = '<span class="source-tab-icon">' + fileIcon({ path: resource.url, type: resource.type }) + '</span><span>' + escapeHtml(sourceFileName(resource.url)) + '</span><span class="source-tab-close">×</span>';
      tab.title = resource.url;
      tab.addEventListener("click", function (e) {
        if (e.target.classList.contains("source-tab-close")) {
          sourceTabs.splice(index, 1);
          if (activeSource && activeSource.url === resource.url) activeSource = sourceTabs[sourceTabs.length - 1] || null;
          renderSourceTabs();
          if (activeSource) renderActiveSource(); else clearSourceEditor();
          return;
        }
        activeSource = resource;
        renderSourceTabs();
        renderActiveSource();
      });
      box.appendChild(tab);
    });
  }

  function setSourceGutter(text) {
    var gutter = document.getElementById("source-gutter");
    if (!gutter) return;
    var count = Math.max(1, String(text || "").split("\n").length);
    var lines = [];
    for (var i = 1; i <= count; i++) lines.push(i);
    gutter.textContent = lines.join("\n");
  }

  function clearSourceEditor() {
    var ed = document.getElementById("source-editor");
    if (ed) ed.value = "";
    setSourceGutter("");
    document.getElementById("source-path").textContent = "No source selected";
    document.getElementById("source-type").textContent = "—";
    document.getElementById("source-status").textContent = "Ready.";
  }

  function renderActiveSource() {
    if (!activeSource) return clearSourceEditor();
    var resource = activeSource;
    document.getElementById("source-path").textContent = resource.url || "resource";
    document.getElementById("source-type").textContent = sourceKind(resource);
    document.getElementById("source-status").textContent = "Loading…";
    if (!resource.getContent) {
      document.getElementById("source-editor").value = "This resource cannot expose source content through the DevTools Resources API.";
      setSourceGutter(document.getElementById("source-editor").value);
      document.getElementById("source-status").textContent = "No getContent() API for this resource.";
      return;
    }
    resource.getContent(function (content, encoding) {
      var ed = document.getElementById("source-editor");
      if (content == null) content = "";
      if (/^(IMAGE|FONT)$/.test(sourceKind(resource))) {
        ed.value = "Binary resource\n\n" + resource.url + "\n\nEncoding: " + (encoding || "binary") + "\n\nUse the network panel to inspect transfer metadata.";
      } else {
        ed.value = String(content);
      }
      setSourceGutter(ed.value);
      document.getElementById("source-status").textContent = (ed.value.split("\n").length).toLocaleString() + " lines · " + sourceKind(resource) + " · " + (encoding || "utf-8");
    });
  }

  function openSourceResource(resource) {
    if (!resource || !resource.url) return;
    var existing = sourceTabs.find(function (r) { return r.url === resource.url; });
    activeSource = existing || resource;
    if (!existing) sourceTabs.push(resource);
    renderSourceTabs();
    switchToView("sources");
    renderActiveSource();
  }

  function renderRealSourcesTree(resources) {
    var hosts = {};
    resources.forEach(function (resource) {
      if (!resource || !resource.url) return;
      try {
        var u = new URL(resource.url);
        var host = u.hostname || "local";
        if (!hosts[host]) hosts[host] = [];
        hosts[host].push({
          url: resource.url,
          path: u.pathname + u.search,
          type: resource.type || "other",
          size: 0,
          __resource: resource
        });
      } catch (e) {}
    });
    hostTree = hosts;
    renderTree(hosts);
    var count = resources.length;
    var head = document.querySelector(".tree-head span");
    if (head) head.textContent = "Page // " + count + " resources";
  }

  function loadRealSources() {
    if (!chrome.devtools || !chrome.devtools.inspectedWindow || !chrome.devtools.inspectedWindow.getResources) {
      buildHostTreeFromPage();
      return;
    }
    chrome.devtools.inspectedWindow.getResources(function (resources) {
      sourceResources = resources || [];
      if (sourceResources.length) {
        renderRealSourcesTree(sourceResources);
        return;
      }
      buildHostTreeFromPage();
    });
  }

  document.getElementById("source-copy").addEventListener("click", function () {
    navigator.clipboard.writeText(document.getElementById("source-editor").value || "");
    document.getElementById("source-status").textContent = "Copied source to clipboard.";
  });
  document.getElementById("source-download").addEventListener("click", function () {
    if (!activeSource) return;
    var blob = new Blob([document.getElementById("source-editor").value || ""], { type: "text/plain" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = sourceFileName(activeSource.url);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 500);
  });
  document.getElementById("source-wrap").addEventListener("click", function () {
    sourceWrap = !sourceWrap;
    document.getElementById("source-editor").wrap = sourceWrap ? "soft" : "off";
    this.classList.toggle("active", sourceWrap);
  });
  document.getElementById("source-refresh").addEventListener("click", function () { loadRealSources(); if (activeSource) renderActiveSource(); });
  document.getElementById("source-editor").addEventListener("scroll", function () {
    document.getElementById("source-gutter").scrollTop = this.scrollTop;
  });
  document.querySelector('.tab[data-view="sources"]').addEventListener("click", function () { loadRealSources(); });

  document.getElementById("tree-search").addEventListener("input", function () {
    if (sourceResources.length) renderRealSourcesTree(sourceResources);
    else buildHostTreeFromPage();
  });
  document.getElementById("tree-refresh").addEventListener("click", function () {
    loadRealSources();
  });

  // Tree top "top" twisty
  document.querySelector('#resource-tree .tree-row').addEventListener("click", function () {
    var node = document.querySelector('#resource-tree .tree-node');
    node.classList.toggle("open");
    this.querySelector(".tree-twisty").textContent = node.classList.contains("open") ? "▼" : "▶";
  });

  // ── Live Editor ─────────────────────────────────────────────
  function loadSelected() {
    evalPage(
      "(function(){ var el=$0; if(!el||el===document)return{error:'Select an element first.'}; var attrs={}; for(var i=0;i<el.attributes.length;i++){var a=el.attributes[i];attrs[a.name]=a.value;} return{tag:el.tagName.toLowerCase(),id:el.id||'',classes:Array.prototype.slice.call(el.classList),text:el.innerText||'',attrs:attrs,style:el.getAttribute('style')||''}; })()",
      function (result, isException) {
        var tagEl = document.getElementById("editor-tag");
        var grid = document.getElementById("editor-grid");
        if (isException || !result || result.error) {
          tagEl.textContent = (result && result.error) || "fail";
          tagEl.className = "mono muted";
          grid.style.display = "none";
          return;
        }
        var label = "<" + result.tag;
        if (result.id) label += ' id="' + result.id + '"';
        if (result.classes.length) label += ' class="' + result.classes.join(" ") + '"';
        label += ">";
        tagEl.textContent = label;
        tagEl.className = "mono green";
        document.getElementById("ed-text").value = result.text;
        document.getElementById("ed-style").value = result.style;
        var attrsBox = document.getElementById("ed-attrs");
        attrsBox.innerHTML = "";
        Object.keys(result.attrs).forEach(function (name) {
          if (name === "style") return;
          var row = document.createElement("div");
          row.className = "attr-row";
          row.innerHTML =
            '<span class="attr-name">' + name + "</span>" +
            '<input class="input attr-val" data-name="' + name + '" value="' +
            String(result.attrs[name]).replace(/"/g, "&quot;") + '">' +
            '<button class="btn btn-sm attr-apply">Set</button>' +
            '<button class="btn btn-sm attr-del">Del</button>';
          attrsBox.appendChild(row);
        });
        attrsBox.querySelectorAll(".attr-apply").forEach(function (btn) {
          btn.addEventListener("click", function () {
            var row = btn.closest(".attr-row");
            evalPage("$0.setAttribute('" + esc(row.querySelector(".attr-val").dataset.name) + "', '" + esc(row.querySelector(".attr-val").value) + "')");
          });
        });
        attrsBox.querySelectorAll(".attr-del").forEach(function (btn) {
          btn.addEventListener("click", function () {
            var row = btn.closest(".attr-row");
            evalPage("$0.removeAttribute('" + esc(row.querySelector(".attr-val").dataset.name) + "')");
            row.remove();
          });
        });
        grid.style.display = "block";
        if (settings.outlineOnLoad) {
          evalPage("$0.style.outline='2px solid #39ff14';$0.style.outlineOffset='2px';");
        }
      }
    );
  }

  document.getElementById("load-selected").addEventListener("click", loadSelected);
  document.getElementById("apply-text").addEventListener("click", function () {
    evalPage("$0.innerText='" + esc(document.getElementById("ed-text").value) + "'");
  });
  document.getElementById("apply-style").addEventListener("click", function () {
    evalPage("$0.setAttribute('style','" + esc(document.getElementById("ed-style").value) + "')");
  });
  document.getElementById("add-attr").addEventListener("click", function () {
    var name = document.getElementById("new-attr-name").value.trim();
    var val = document.getElementById("new-attr-val").value;
    if (!name) return;
    evalPage("$0.setAttribute('" + esc(name) + "','" + esc(val) + "')", function () {
      document.getElementById("new-attr-name").value = "";
      document.getElementById("new-attr-val").value = "";
      loadSelected();
    });
  });
  document.querySelectorAll("[data-toggle]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      evalPage("$0.style." + btn.dataset.toggle + "='" + esc(btn.dataset.val) + "'");
    });
  });
  document.getElementById("toggle-outline").addEventListener("click", function () {
    evalPage("(function(){if($0.style.outline&&$0.style.outline!=='none'){$0.style.outline='none';$0.style.outlineOffset='';}else{$0.style.outline='2px solid #39ff14';$0.style.outlineOffset='2px';}})()");
  });
  document.getElementById("delete-el").addEventListener("click", function () {
    evalPage("$0.remove()");
    document.getElementById("editor-grid").style.display = "none";
    document.getElementById("editor-tag").textContent = "gone.";
    document.getElementById("editor-tag").className = "mono muted";
  });
  document.getElementById("apply-qv").addEventListener("click", function () {
    var prop = document.getElementById("qv-prop").value;
    var val = document.getElementById("qv-val").value;
    if (prop === "disabled" || prop === "checked") {
      evalPage("$0." + prop + "=" + (val === "true" || val === "1"));
    } else if (prop === "innerHTML" || prop === "innerText") {
      evalPage("$0." + prop + "='" + esc(val) + "'");
    } else {
      evalPage("$0.setAttribute('" + esc(prop) + "','" + esc(val) + "');if('" + prop + "' in $0)$0['" + prop + "']='" + esc(val) + "';");
    }
  });

  // ── Network ─────────────────────────────────────────────────
  function headersToText(headers) {
    if (!headers || !headers.length) return "";
    return headers.map(function (h) { return h.name + ": " + h.value; }).join("\n");
  }

  function headersToView(headers, el) {
    el.innerHTML = "";
    if (!headers || !headers.length) {
      el.innerHTML = '<span class="hv muted">none</span>';
      return;
    }
    headers.forEach(function (h) {
      el.innerHTML +=
        '<span class="hk">' + escapeHtml(h.name) + "</span>" +
        '<span class="hv">' + escapeHtml(h.value) + "</span>";
    });
  }

  function textToHeadersObj(text) {
    var obj = {};
    (text || "").split("\n").forEach(function (line) {
      var i = line.indexOf(":");
      if (i > 0) {
        var n = line.slice(0, i).trim();
        var v = line.slice(i + 1).trim();
        if (n) obj[n] = v;
      }
    });
    return obj;
  }

  function formatBytes(n) {
    if (n == null || n < 0) return "—";
    if (n < 1024) return n + "B";
    if (n < 1048576) return (n / 1024).toFixed(1) + "K";
    return (n / 1048576).toFixed(1) + "M";
  }

  function classifyType(entry) {
    var rt = "";
    if (entry._resourceType) rt = String(entry._resourceType).toLowerCase();
    if (rt === "xhr") return "xhr";
    if (rt === "fetch") return "fetch";
    if (rt === "websocket" || rt === "ws") return "ws";
    if (rt === "document") return "doc";
    if (rt === "script") return "script";
    if (rt === "stylesheet") return "stylesheet";
    if (rt === "image") return "image";
    if (rt === "font") return "font";
    if (rt === "media") return "media";

    var mime = "";
    try {
      mime = ((entry.response && entry.response.content && entry.response.content.mimeType) || "").toLowerCase();
    } catch (e) {}
    if (mime.indexOf("javascript") !== -1) return "script";
    if (mime.indexOf("css") !== -1) return "stylesheet";
    if (mime.indexOf("image/") === 0) return "image";
    if (mime.indexOf("json") !== -1) return "xhr";
    if (mime.indexOf("html") !== -1) return "doc";

    try {
      var p = new URL(entry.request && entry.request.url || entry.url || "", location.href).pathname.toLowerCase();
      if (/\.scss$/.test(p)) return "scss";
      if (/\.html?$/.test(p)) return "doc";
      if (/\.json$/.test(p)) return "xhr";
    } catch (e) {}

    var headers = (entry.request && entry.request.headers) || [];
    for (var i = 0; i < headers.length; i++) {
      var n = (headers[i].name || "").toLowerCase();
      var v = (headers[i].value || "").toLowerCase();
      if (n === "x-requested-with" && v.indexOf("xmlhttprequest") !== -1) return "xhr";
      if (n === "sec-fetch-mode" && v === "cors") return "fetch";
    }
    return "other";
  }

  function typeLabel(t) {
    return ({ xhr: "xhr", fetch: "fetch", doc: "doc", script: "js", stylesheet: "css", image: "img", font: "font", media: "media", ws: "ws", other: "…" })[t] || t;
  }

  function captureFromHarEntry(entry) {
    var type = classifyType(entry);
    var size = -1;
    try {
      if (entry.response && entry.response.content && entry.response.content.size >= 0) size = entry.response.content.size;
      else if (entry.response && entry.response.bodySize >= 0) size = entry.response.bodySize;
    } catch (e) {}

    return {
      id: "n" + (++netIdSeq),
      url: entry.request.url,
      method: entry.request.method,
      status: entry.response ? entry.response.status : 0,
      statusText: entry.response ? entry.response.statusText : "",
      mime: entry.response && entry.response.content ? entry.response.content.mimeType : "",
      size: size,
      time: entry.time,
      type: type,
      reqHeaders: entry.request.headers || [],
      resHeaders: entry.response ? entry.response.headers || [] : [],
      reqBody: (entry.request.postData && entry.request.postData.text) || "",
      resBody: "",
      timing: entry.timings || null,
      httpVersion: entry.response ? entry.response.httpVersion : ""
    };
  }

  function captureRequest(request) {
    try {
      var entry = {
        request: request.request,
        response: request.response,
        time: request.time,
        timings: request.timings,
        _resourceType: request._resourceType
      };
      var item = captureFromHarEntry(entry);
      if (typeof request.getContent === "function") {
        request.getContent(function (content, encoding) {
          if (content != null) {
            item.resBody = encoding === "base64"
              ? "[binary " + content.length + "]"
              : String(content).slice(0, 100000);
            if (selectedNet && selectedNet.id === item.id) {
              document.getElementById("net-res-body").value = item.resBody;
            }
          }
        });
      }
      netRequests.push(item);
      if (netRequests.length > 300) netRequests.shift();
      renderNetList();
      // refresh tree occasionally
      if (netRequests.length % 5 === 0) buildHostTreeFromPage();
    } catch (e) {
      console.error(e);
    }
  }

  function renderNetList() {
    var filter = (document.getElementById("net-filter").value || "").toLowerCase();
    var box = document.getElementById("net-list");
    var items = netRequests.filter(function (r) {
      if (netTypeFilter !== "all" && r.type !== netTypeFilter) return false;
      if (!filter) return true;
      return (
        (r.url || "").toLowerCase().indexOf(filter) !== -1 ||
        (r.method || "").toLowerCase().indexOf(filter) !== -1 ||
        String(r.status).indexOf(filter) !== -1 ||
        (r.type || "").indexOf(filter) !== -1
      );
    });

    document.getElementById("net-count").textContent = items.length + "/" + netRequests.length;

    if (!items.length) {
      box.className = "net-list mono muted";
      box.textContent = netRequests.length ? "no matches" : "waiting for packets…";
      return;
    }

    box.className = "net-list";
    box.innerHTML = "";
    items.slice().reverse().forEach(function (r) {
      var row = document.createElement("div");
      row.className = "net-row" + (selectedNet && selectedNet.id === r.id ? " active" : "");
      var sc = r.status >= 500 ? "s5" : r.status >= 400 ? "s4" : r.status >= 300 ? "s3" : "s2";
      var shortUrl = r.url || "";
      try {
        var u = new URL(r.url);
        shortUrl = u.pathname + u.search;
        if (shortUrl.length > 60) shortUrl = shortUrl.slice(0, 57) + "…";
      } catch (e) {}
      row.innerHTML =
        '<span class="net-method">' + escapeHtml(r.method || "?") + "</span>" +
        '<span class="net-status ' + sc + '">' + (r.status || "—") + "</span>" +
        '<span class="net-type">' + typeLabel(r.type) + "</span>" +
        '<span class="net-url" title="' + escapeHtml(r.url || "") + '">' + escapeHtml(shortUrl) + "</span>" +
        '<span class="net-size">' + formatBytes(r.size) + "</span>" +
        '<span class="net-time">' + (r.time != null ? Math.round(r.time) + "ms" : "—") + "</span>";
      row.addEventListener("click", function () {
        selectedNet = r;
        showNetDetail(r);
        renderNetList();
      });
      box.appendChild(row);
    });
  }

  function showNetDetail(r) {
    document.getElementById("net-detail-box").style.display = "block";
    document.getElementById("net-detail-title").textContent =
      (r.method || "") + " · " + typeLabel(r.type);

    document.getElementById("net-summary").innerHTML =
      "<span><strong>status</strong> " + (r.status || "—") + "</span>" +
      "<span><strong>type</strong> " + typeLabel(r.type) + "</span>" +
      "<span><strong>size</strong> " + formatBytes(r.size) + "</span>" +
      "<span><strong>time</strong> " + (r.time != null ? Math.round(r.time) + "ms" : "—") + "</span>";

    document.getElementById("net-general").innerHTML =
      '<span class="hk">URL</span><span class="hv">' + escapeHtml(r.url) + "</span>" +
      '<span class="hk">Method</span><span class="hv">' + escapeHtml(r.method) + "</span>" +
      '<span class="hk">Status</span><span class="hv">' + (r.status || "—") + " " + escapeHtml(r.statusText || "") + "</span>";

    headersToView(r.reqHeaders, document.getElementById("net-req-headers-view"));
    headersToView(r.resHeaders, document.getElementById("net-res-headers-view"));
    document.getElementById("net-payload-view").value = r.reqBody || "";
    document.getElementById("net-res-body").value = r.resBody || "(loading or n/a)";
    document.getElementById("net-method").value = r.method || "GET";
    document.getElementById("net-url").value = r.url || "";
    document.getElementById("net-req-headers").value = headersToText(r.reqHeaders);
    document.getElementById("net-req-body").value = r.reqBody || "";
    document.getElementById("net-replay-out").textContent = "";

    var timingEl = document.getElementById("net-timing-view");
    if (r.timing) {
      var t = r.timing;
      function ms(v) { return v == null || v < 0 ? "—" : Math.round(v) + "ms"; }
      timingEl.innerHTML =
        '<span class="hk">Blocked</span><span class="hv">' + ms(t.blocked) + "</span>" +
        '<span class="hk">DNS</span><span class="hv">' + ms(t.dns) + "</span>" +
        '<span class="hk">Connect</span><span class="hv">' + ms(t.connect) + "</span>" +
        '<span class="hk">SSL</span><span class="hv">' + ms(t.ssl) + "</span>" +
        '<span class="hk">Send</span><span class="hv">' + ms(t.send) + "</span>" +
        '<span class="hk">Wait</span><span class="hv">' + ms(t.wait) + "</span>" +
        '<span class="hk">Receive</span><span class="hv">' + ms(t.receive) + "</span>";
    } else {
      timingEl.innerHTML = '<span class="hv muted">no timing data</span>';
    }
  }


  // ── Persistent saved XHR / Fetch edits ──────────────────────
  var savedXhrs = {};
  var activeSavedXhr = "";
  function loadSavedXhrs(done) {
    chrome.storage.local.get(["richaf_saved_xhrs"], function (data) {
      savedXhrs = data.richaf_saved_xhrs || {};
      renderSavedXhrs();
      if (done) done();
    });
  }
  function requestDraftFromUI() {
    return {
      method: document.getElementById("net-method").value || "GET",
      url: document.getElementById("net-url").value.trim(),
      headers: document.getElementById("net-req-headers").value || "",
      body: document.getElementById("net-req-body").value || ""
    };
  }
  function xhrKey(draft) { return String(draft.method || "GET").toUpperCase() + " " + String(draft.url || ""); }
  function renderSavedXhrs() {
    var select = document.getElementById("net-saved-select");
    var list = document.getElementById("net-saved-list");
    if (select) {
      select.innerHTML = '<option value="">Select saved request…</option>';
      Object.keys(savedXhrs).sort().forEach(function (key) {
        var option = document.createElement("option");
        option.value = key; option.textContent = key.length > 85 ? key.slice(0,82) + "…" : key;
        select.appendChild(option);
      });
      if (activeSavedXhr && savedXhrs[activeSavedXhr]) select.value = activeSavedXhr;
    }
    if (!list) return;
    list.innerHTML = "";
    var keys = Object.keys(savedXhrs).sort();
    if (!keys.length) {
      list.innerHTML = '<div class="saved-empty">No saved requests yet. Select a request below, edit it, then choose <b>Save XHR</b>.</div>';
      return;
    }
    keys.forEach(function (key) {
      var item = savedXhrs[key];
      var row = document.createElement("div"); row.className = "saved-xhr-item";
      var main = document.createElement("button"); main.className = "saved-xhr-main"; main.type = "button";
      main.innerHTML = '<span class="saved-method">' + escapeHtml(item.method || "GET") + '</span><span class="saved-url">' + escapeHtml(item.url || key) + '</span>';
      main.addEventListener("click", function () { applySavedXhr(key); });
      var edit = document.createElement("button"); edit.className = "btn btn-sm"; edit.textContent = "Edit"; edit.addEventListener("click", function(){ applySavedXhr(key); });
      var del = document.createElement("button"); del.className = "btn btn-sm btn-danger"; del.textContent = "×"; del.title = "Delete saved request";
      del.addEventListener("click", function(){ deleteSavedXhr(key); });
      row.appendChild(main); row.appendChild(edit); row.appendChild(del); list.appendChild(row);
    });
  }
  function saveDraft(draft, replaceKey) {
    if (!draft.url) return;
    var key = replaceKey || xhrKey(draft);
    savedXhrs[key] = Object.assign({}, draft, { savedAt: Date.now() });
    if (replaceKey && replaceKey !== key) delete savedXhrs[replaceKey];
    activeSavedXhr = key;
    chrome.storage.local.set({ richaf_saved_xhrs: savedXhrs }, function () {
      renderSavedXhrs();
      var out = document.getElementById("net-replay-out");
      if (out) out.textContent = "Saved " + key + " locally. It will still be here after RichAF and page reloads.";
    });
  }
  function saveCurrentXhr() { saveDraft(requestDraftFromUI(), ""); }
  function updateCurrentSavedXhr() {
    var draft = requestDraftFromUI();
    if (!activeSavedXhr) { saveDraft(draft, ""); return; }
    saveDraft(draft, activeSavedXhr);
  }
  function deleteSavedXhr(key) {
    if (!key || !savedXhrs[key]) return;
    delete savedXhrs[key];
    if (activeSavedXhr === key) activeSavedXhr = "";
    chrome.storage.local.set({ richaf_saved_xhrs: savedXhrs }, renderSavedXhrs);
  }
  function applySavedXhr(key) {
    var item = savedXhrs[key];
    if (!item) return;
    activeSavedXhr = key;
    var detail = document.getElementById("net-detail-box"); if (detail) detail.style.display = "block";
    document.getElementById("net-method").value = item.method || "GET";
    document.getElementById("net-url").value = item.url || "";
    document.getElementById("net-req-headers").value = item.headers || "";
    document.getElementById("net-req-body").value = item.body || "";
    document.getElementById("net-replay-out").textContent = "Editing saved request. Make changes, then click Update saved.";
    document.querySelectorAll(".net-tab").forEach(function(t){t.classList.toggle("active", t.dataset.tab === "edit");});
    document.querySelectorAll(".net-tab-pane").forEach(function(p){p.classList.toggle("active", p.id === "tab-edit");});
    var select = document.getElementById("net-saved-select"); if (select) select.value = key;
    renderSavedXhrs();
  }
  document.getElementById("net-save").addEventListener("click", saveCurrentXhr);
  document.getElementById("net-update-saved").addEventListener("click", updateCurrentSavedXhr);
  document.getElementById("net-new-xhr").addEventListener("click", function(){
    activeSavedXhr = ""; selectedNet = null;
    document.getElementById("net-detail-box").style.display = "block";
    document.getElementById("net-method").value = "GET";
    document.getElementById("net-url").value = "";
    document.getElementById("net-req-headers").value = "";
    document.getElementById("net-req-body").value = "";
    document.getElementById("net-replay-out").textContent = "Create a request, then click Save XHR.";
    document.querySelector('[data-tab="edit"]').click();
  });
  document.getElementById("net-load-saved").addEventListener("click", function () { var key = document.getElementById("net-saved-select").value; if (key) applySavedXhr(key); });
  document.getElementById("net-delete-saved").addEventListener("click", function () { var key = document.getElementById("net-saved-select").value; if (key) deleteSavedXhr(key); });
  loadSavedXhrs();

  document.querySelectorAll(".net-tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      document.querySelectorAll(".net-tab").forEach(function (t) { t.classList.remove("active"); });
      document.querySelectorAll(".net-tab-pane").forEach(function (p) { p.classList.remove("active"); });
      tab.classList.add("active");
      document.getElementById("tab-" + tab.dataset.tab).classList.add("active");
    });
  });

  document.querySelectorAll(".net-chip").forEach(function (chip) {
    chip.addEventListener("click", function () {
      document.querySelectorAll(".net-chip").forEach(function (c) { c.classList.remove("active"); });
      chip.classList.add("active");
      netTypeFilter = chip.dataset.type;
      renderNetList();
    });
  });

  document.getElementById("net-filter").addEventListener("input", renderNetList);
  document.getElementById("net-clear").addEventListener("click", function () {
    netRequests = [];
    selectedNet = null;
    document.getElementById("net-detail-box").style.display = "none";
    renderNetList();
  });
  document.getElementById("net-preserve").addEventListener("click", function () {
    preserveLog = !preserveLog;
    this.style.borderColor = preserveLog ? "#39ff14" : "";
    this.style.color = preserveLog ? "#39ff14" : "";
  });
  document.getElementById("net-detail-close").addEventListener("click", function () {
    document.getElementById("net-detail-box").style.display = "none";
    selectedNet = null;
    renderNetList();
  });
  document.getElementById("net-res-format").addEventListener("click", function () {
    var el = document.getElementById("net-res-body");
    try { el.value = JSON.stringify(JSON.parse(el.value), null, 2); } catch (e) {}
  });
  document.getElementById("net-res-copy").addEventListener("click", function () {
    navigator.clipboard.writeText(document.getElementById("net-res-body").value);
  });

  if (chrome.devtools && chrome.devtools.network) {
    chrome.devtools.network.onRequestFinished.addListener(captureRequest);
    chrome.devtools.network.onNavigated.addListener(function () {
      if (!preserveLog) {
        netRequests = [];
        selectedNet = null;
        document.getElementById("net-detail-box").style.display = "none";
        renderNetList();
      }
      setTimeout(buildHostTreeFromPage, 500);
    });

    function pullHAR() {
      chrome.devtools.network.getHAR(function (har) {
        if (!har || !har.entries) return;
        har.entries.forEach(function (entry) {
          var exists = netRequests.some(function (r) {
            return r.url === entry.request.url &&
              Math.abs((r.time || 0) - (entry.time || 0)) < 0.5 &&
              r.method === entry.request.method;
          });
          if (!exists) netRequests.push(captureFromHarEntry(entry));
        });
        if (netRequests.length > 300) netRequests = netRequests.slice(-300);
        renderNetList();
        buildHostTreeFromPage();
      });
    }
    document.getElementById("net-refresh").addEventListener("click", pullHAR);
    setTimeout(pullHAR, 400);
  }

  document.getElementById("net-replay").addEventListener("click", function () {
    var method = document.getElementById("net-method").value;
    var url = document.getElementById("net-url").value;
    var headers = textToHeadersObj(document.getElementById("net-req-headers").value);
    var body = document.getElementById("net-req-body").value;
    var out = document.getElementById("net-replay-out");
    ["Host", "host", "Content-Length", "content-length", "Origin", "origin"].forEach(function (k) { delete headers[k]; });
    var code =
      "(function(){var opts={method:'" + esc(method) + "',headers:" + JSON.stringify(headers) + ",credentials:'include'};" +
      (body && method !== "GET" && method !== "HEAD" ? "opts.body='" + esc(body) + "';" : "") +
      "return fetch('" + esc(url) + "',opts).then(function(r){return r.text().then(function(t){return{status:r.status,statusText:r.statusText,headers:Array.from(r.headers.entries()),body:t.slice(0,50000)};});}).catch(function(e){return{error:e.message};});})()";
    out.textContent = "sending…";
    evalPage(code, function (result, isException) {
      if (isException) { out.textContent = "err: " + JSON.stringify(isException); return; }
      if (!result) { out.textContent = "no result"; return; }
      if (result.error) { out.textContent = "err: " + result.error; return; }
      var hdrs = (result.headers || []).map(function (h) { return h[0] + ": " + h[1]; }).join("\n");
      out.textContent = "Status: " + result.status + " " + (result.statusText || "") + "\n\n" + hdrs + "\n\n" + (result.body || "");
    });
  });

  document.getElementById("net-copy-fetch").addEventListener("click", function () {
    var method = document.getElementById("net-method").value;
    var url = document.getElementById("net-url").value;
    var headers = textToHeadersObj(document.getElementById("net-req-headers").value);
    var body = document.getElementById("net-req-body").value;
    delete headers.Host; delete headers.host;
    var opts = { method: method, headers: headers, credentials: "include" };
    if (body && method !== "GET" && method !== "HEAD") opts.body = body;
    navigator.clipboard.writeText("fetch(" + JSON.stringify(url) + ", " + JSON.stringify(opts, null, 2) + ")");
    document.getElementById("net-replay-out").textContent = "copied fetch()";
  });

  document.getElementById("net-copy-curl").addEventListener("click", function () {
    var method = document.getElementById("net-method").value;
    var url = document.getElementById("net-url").value;
    var headers = textToHeadersObj(document.getElementById("net-req-headers").value);
    var body = document.getElementById("net-req-body").value;
    var parts = ["curl -X " + method + " " + JSON.stringify(url)];
    Object.keys(headers).forEach(function (k) {
      if (k.toLowerCase() === "host" || k.toLowerCase() === "content-length") return;
      parts.push("-H " + JSON.stringify(k + ": " + headers[k]));
    });
    if (body && method !== "GET" && method !== "HEAD") parts.push("--data-raw " + JSON.stringify(body));
    navigator.clipboard.writeText(parts.join(" \\\n  "));
    document.getElementById("net-replay-out").textContent = "copied cURL";
  });

  document.getElementById("net-override").addEventListener("click", function () {
    var url = document.getElementById("net-url").value;
    var match = url;
    try { match = new URL(url).pathname; } catch (e) {}
    document.getElementById("ov-match").value = match;
    document.getElementById("net-replay-out").textContent = "match filled → enable override below";
  });

  function overrideHeadersObject(text) {
    var out = {};
    String(text || "").split(/\r?\n/).forEach(function (line) {
      var i = line.indexOf(":");
      if (i <= 0) return;
      var key = line.slice(0, i).trim();
      var value = line.slice(i + 1).trim();
      if (key) out[key] = value;
    });
    return out;
  }

  function getOverrideRule() {
    return {
      match: document.getElementById("ov-match").value.trim(),
      methods: document.getElementById("ov-methods").value.split(",").map(function (x) { return x.trim().toUpperCase(); }).filter(Boolean),
      mode: document.getElementById("ov-mode").value,
      status: parseInt(document.getElementById("ov-status").value, 10) || 200,
      delay: Math.max(0, Math.min(60000, parseInt(document.getElementById("ov-delay").value, 10) || 0)),
      contentType: document.getElementById("ov-content-type").value.trim() || "application/json",
      headers: overrideHeadersObject(document.getElementById("ov-headers").value),
      body: document.getElementById("ov-body").value,
      requestBody: document.getElementById("ov-request-body").value
    };
  }

  function setOverrideState(on, text) {
    var state = document.getElementById("ov-state");
    if (!state) return;
    state.textContent = on ? "ON" : "OFF";
    state.className = "override-state " + (on ? "on" : "off");
    document.getElementById("ov-log").textContent = text || (on ? "Fetch + XHR interception installed for this page." : "Override engine is idle.");
  }

  function installFetchOverride(rule, cb) {
    var payload = JSON.stringify(rule);
    var code = "(function(){" +
      "var rule=" + payload + ";" +
      "var state=window.__RICHAF_OVERRIDE_STATE__||(window.__RICHAF_OVERRIDE_STATE__={});" +
      "state.rule=rule;" +
      "if(!state.originalFetch)state.originalFetch=window.fetch;" +
      "if(!state.originalXHR){state.originalXHR={open:XMLHttpRequest.prototype.open,send:XMLHttpRequest.prototype.send,setRequestHeader:XMLHttpRequest.prototype.setRequestHeader};}" +
      "function match(url,method){var m=String(rule.match||'');var ok=!m||String(url).indexOf(m)!==-1;var methods=rule.methods||[];var mok=!methods.length||methods.indexOf(String(method||'GET').toUpperCase())!==-1;return ok&&mok;}" +
      "function wait(ms){return ms>0?new Promise(function(r){setTimeout(r,ms);}):Promise.resolve();}" +
      "function headers(){var h=Object.assign({},rule.headers||{});if(rule.contentType&&!Object.keys(h).some(function(k){return k.toLowerCase()==='content-type';}))h['Content-Type']=rule.contentType;return h;}" +
      "function mock(){return new Response(rule.body||'',{status:rule.status||200,headers:headers()});}" +
      "window.fetch=function(input,init){" +
        "var url=typeof input==='string'?input:(input&&input.url)||'';" +
        "var method=(init&&init.method)||(input&&input.method)||'GET';" +
        "if(!match(url,method))return state.originalFetch.apply(this,arguments);" +
        "if(rule.mode==='block')return wait(rule.delay).then(function(){throw new TypeError('Failed to fetch (blocked by RichAF)');});" +
        "if(rule.mode==='mock'||rule.mode==='force')return wait(rule.delay).then(mock);" +
        "if(rule.requestBody&&init&&typeof init.body==='string')init=Object.assign({},init,{body:rule.requestBody});" +
        "return wait(rule.delay).then(function(){return state.originalFetch.call(this,input,init);}.bind(this));" +
      "};" +
      "XMLHttpRequest.prototype.open=function(method,url){this.__rafOverrideUrl=url;this.__rafOverrideMethod=method;return state.originalXHR.open.apply(this,arguments);};" +
      "XMLHttpRequest.prototype.send=function(body){var xhr=this,url=String(xhr.__rafOverrideUrl||''),method=String(xhr.__rafOverrideMethod||'GET');" +
        "if(!match(url,method))return state.originalXHR.send.call(this,body);" +
        "if(rule.mode==='pass')return state.originalXHR.send.call(this,rule.requestBody&&typeof body==='string'?rule.requestBody:body);" +
        "if(rule.mode==='block'){setTimeout(function(){try{xhr.abort();}catch(e){}},rule.delay||0);return;}" +
        "var fire=function(){try{Object.defineProperty(xhr,'status',{configurable:true,get:function(){return rule.status||200;}});Object.defineProperty(xhr,'statusText',{configurable:true,get:function(){return 'RichAF Override';}});Object.defineProperty(xhr,'responseText',{configurable:true,get:function(){return rule.body||'';}});Object.defineProperty(xhr,'response',{configurable:true,get:function(){return rule.body||'';}});Object.defineProperty(xhr,'readyState',{configurable:true,get:function(){return 4;}});}catch(e){};if(typeof xhr.onreadystatechange==='function')xhr.onreadystatechange(new Event('readystatechange'));if(typeof xhr.onload==='function')xhr.onload(new Event('load'));if(typeof xhr.onloadend==='function')xhr.onloadend(new Event('loadend'));};" +
        "setTimeout(fire,rule.delay||0);" +
      "};" +
      "state.enabled=true;return {enabled:true,rule:rule};})()";
    evalPage(code, function (result, isException) {
      if (isException) { setOverrideState(false, "Install failed: " + JSON.stringify(isException)); if (cb) cb(false); return; }
      setOverrideState(true, "Installed. Matching " + (rule.match || "all URLs") + " · " + rule.mode + " · " + (rule.methods.join(", ") || "all methods"));
      if (cb) cb(true, result);
    });
  }

  document.getElementById("ov-enable").addEventListener("click", function () {
    var rule = getOverrideRule();
    installFetchOverride(rule);
  });

  document.getElementById("ov-disable").addEventListener("click", function () {
    evalPage("(function(){var s=window.__RICHAF_OVERRIDE_STATE__;if(!s)return false;if(s.originalFetch)window.fetch=s.originalFetch;if(s.originalXHR){XMLHttpRequest.prototype.open=s.originalXHR.open;XMLHttpRequest.prototype.send=s.originalXHR.send;XMLHttpRequest.prototype.setRequestHeader=s.originalXHR.setRequestHeader;}delete window.__RICHAF_OVERRIDE_STATE__;return true;})()", function (result, isException) {
      setOverrideState(false, isException ? "Could not remove override." : "Override removed from the page.");
    });
  });

  document.getElementById("ov-test").addEventListener("click", function () {
    var rule = getOverrideRule();
    var testUrl = rule.match || location.href;
    var testMethod = rule.methods[0] || "GET";
    var out = document.getElementById("ov-log");
    out.textContent = "Testing " + testMethod + " " + testUrl + "…";
    var code = "fetch(" + JSON.stringify(testUrl) + ",{method:" + JSON.stringify(testMethod) + "}).then(function(r){return r.text().then(function(t){return {status:r.status,body:t.slice(0,5000),headers:Array.from(r.headers.entries())};});}).catch(function(e){return {error:String(e&&e.message||e)};})";
    evalPage(code, function (result) { out.textContent = JSON.stringify(result, null, 2); });
  });

  document.getElementById("ov-copy").addEventListener("click", function () {
    navigator.clipboard.writeText(JSON.stringify(getOverrideRule(), null, 2));
    document.getElementById("ov-log").textContent = "Copied override rule JSON.";
  });

  document.getElementById("ov-mode").addEventListener("change", function () {
    var mock = this.value === "mock";
    document.getElementById("ov-body").disabled = !mock;
    document.getElementById("ov-status").disabled = !mock;
    document.getElementById("ov-content-type").disabled = !mock;
  });
  document.getElementById("ov-mode").dispatchEvent(new Event("change"));

  // ── Storage ─────────────────────────────────────────────────
  function loadStorage(type) {
    currentStorage = type;
    evalPage(
      "(function(){var s=window['" + type + "'];var out={};for(var i=0;i<s.length;i++){var k=s.key(i);out[k]=s.getItem(k);}return out;})()",
      function (result, isException) {
        var box = document.getElementById("storage-list");
        if (isException || !result) {
          box.textContent = "could not read";
          box.className = "mono muted";
          return;
        }
        var keys = Object.keys(result);
        if (!keys.length) {
          box.textContent = type + " empty";
          box.className = "mono muted";
          return;
        }
        box.className = "";
        box.innerHTML = "";
        keys.forEach(function (k) {
          var item = document.createElement("div");
          item.className = "stor-item";
          var dv = (result[k] || "").length > 60 ? (result[k] || "").slice(0, 60) + "…" : (result[k] || "");
          item.innerHTML =
            '<span class="stor-key">' + escapeHtml(k) + "</span>" +
            '<span class="stor-val">' + escapeHtml(dv) + "</span>" +
            '<button class="btn btn-sm stor-edit">Edit</button>' +
            '<button class="btn btn-sm stor-del">Del</button>';
          item.querySelector(".stor-edit").addEventListener("click", function () {
            document.getElementById("stor-key").value = k;
            document.getElementById("stor-val").value = result[k] || "";
          });
          item.querySelector(".stor-del").addEventListener("click", function () {
            evalPage("window['" + currentStorage + "'].removeItem('" + esc(k) + "')", function () {
              loadStorage(currentStorage);
            });
          });
          box.appendChild(item);
        });
      }
    );
  }

  document.getElementById("load-local").addEventListener("click", function () { loadStorage("localStorage"); });
  document.getElementById("load-session").addEventListener("click", function () { loadStorage("sessionStorage"); });
  document.getElementById("clear-storage").addEventListener("click", function () {
    evalPage("window['" + currentStorage + "'].clear()", function () { loadStorage(currentStorage); });
  });
  document.getElementById("stor-set").addEventListener("click", function () {
    var k = document.getElementById("stor-key").value.trim();
    var v = document.getElementById("stor-val").value;
    if (!k) return;
    evalPage("window['" + currentStorage + "'].setItem('" + esc(k) + "','" + esc(v) + "')", function () {
      loadStorage(currentStorage);
    });
  });


  // ── Cookies ─────────────────────────────────────────────────
  var selectedCookie = null;
  var inspectedPageUrl = "";
  function getInspectedUrl(cb) {
    evalPage("location.href", function (result, exceptionInfo) {
      if (exceptionInfo || !result) { cb(null); return; }
      inspectedPageUrl = String(result);
      var el = document.getElementById("cookie-page-url");
      if (el) el.textContent = inspectedPageUrl;
      cb(inspectedPageUrl);
    });
  }
  function cookieStatus(text, bad) {
    var el = document.getElementById("cookie-status");
    if (el) { el.textContent = text || ""; el.className = "status-line" + (bad ? " error" : ""); }
  }
  function clearCookieEditor() {
    selectedCookie = null;
    ["cookie-name","cookie-value","cookie-domain"].forEach(function (id) { document.getElementById(id).value = ""; });
    document.getElementById("cookie-path").value = "/";
    document.getElementById("cookie-samesite").value = "no_restriction";
    document.getElementById("cookie-secure").checked = false;
    document.getElementById("cookie-http-only").checked = false;
    cookieStatus("New cookie");
  }
  function fillCookie(c) {
    selectedCookie = c;
    document.getElementById("cookie-name").value = c.name || "";
    document.getElementById("cookie-value").value = c.value || "";
    document.getElementById("cookie-domain").value = c.domain || "";
    document.getElementById("cookie-path").value = c.path || "/";
    document.getElementById("cookie-samesite").value = String(c.sameSite || "no_restriction").toLowerCase();
    document.getElementById("cookie-secure").checked = !!c.secure;
    document.getElementById("cookie-http-only").checked = !!c.httpOnly;
    cookieStatus("Editing " + c.name);
  }
  function cookieUrlFor(domain, secure, path) {
    var host = String(domain || "").replace(/^\./, "");
    var scheme = secure ? "https://" : (/^https:/i.test(inspectedPageUrl) ? "https://" : "http://");
    return scheme + host + (path && path.charAt(0) === "/" ? path : "/" + (path || ""));
  }
  function loadCookies() {
    getInspectedUrl(function (pageUrl) {
      var list = document.getElementById("cookie-list");
      if (!pageUrl || !chrome.cookies || !chrome.cookies.getAll) {
        list.textContent = "Cookies API unavailable in this Chrome build.";
        return;
      }
      chrome.cookies.getAll({ url: pageUrl }, function (cookies) {
        if (chrome.runtime && chrome.runtime.lastError) {
          list.textContent = chrome.runtime.lastError.message;
          return;
        }
        cookies = cookies || [];
        list.className = cookies.length ? "cookie-list" : "cookie-list mono muted";
        if (!cookies.length) { list.textContent = "No cookies for this page."; return; }
        list.innerHTML = "";
        cookies.forEach(function (c) {
          var row = document.createElement("div");
          row.className = "cookie-row";
          row.innerHTML = '<span class="cookie-name">' + escapeHtml(c.name) + '</span><span class="cookie-value">' + escapeHtml(c.value || "") + '</span><span class="cookie-meta">' + escapeHtml(c.domain + c.path) + '</span><button class="btn btn-sm cookie-edit">Edit</button><button class="btn btn-sm btn-danger cookie-del">Del</button>';
          row.querySelector(".cookie-edit").addEventListener("click", function () { fillCookie(c); });
          row.querySelector(".cookie-del").addEventListener("click", function () {
            chrome.cookies.remove({ url: cookieUrlFor(c.domain, c.secure, c.path), name: c.name, storeId: c.storeId }, function () { loadCookies(); });
          });
          list.appendChild(row);
        });
      });
    });
  }
  document.getElementById("cookies-refresh").addEventListener("click", loadCookies);
  document.getElementById("cookie-new").addEventListener("click", clearCookieEditor);
  document.getElementById("cookie-save").addEventListener("click", function () {
    var name = document.getElementById("cookie-name").value.trim();
    var value = document.getElementById("cookie-value").value;
    var domain = document.getElementById("cookie-domain").value.trim();
    var pathValue = document.getElementById("cookie-path").value.trim() || "/";
    var secure = document.getElementById("cookie-secure").checked;
    var sameSite = document.getElementById("cookie-samesite").value;
    if (!name) { cookieStatus("Cookie name is required.", true); return; }
    if (!domain) {
      try { domain = new URL(inspectedPageUrl).hostname; } catch (_) {}
    }
    var details = { url: cookieUrlFor(domain, secure, pathValue), name: name, value: value, path: pathValue, secure: secure, httpOnly: document.getElementById("cookie-http-only").checked, sameSite: sameSite };
    if (selectedCookie && selectedCookie.name !== name) {
      chrome.cookies.remove({ url: cookieUrlFor(selectedCookie.domain, selectedCookie.secure, selectedCookie.path), name: selectedCookie.name, storeId: selectedCookie.storeId }, function () { setCookie(details); });
    } else setCookie(details);
    function setCookie(d) {
      if (selectedCookie && selectedCookie.storeId) d.storeId = selectedCookie.storeId;
      chrome.cookies.set(d, function () {
        if (chrome.runtime && chrome.runtime.lastError) cookieStatus(chrome.runtime.lastError.message, true);
        else { cookieStatus("Cookie saved."); loadCookies(); }
      });
    }
  });
  document.getElementById("cookie-delete").addEventListener("click", function () {
    if (!selectedCookie) { cookieStatus("Select a cookie first.", true); return; }
    chrome.cookies.remove({ url: cookieUrlFor(selectedCookie.domain, selectedCookie.secure, selectedCookie.path), name: selectedCookie.name, storeId: selectedCookie.storeId }, function () { cookieStatus("Cookie deleted."); loadCookies(); clearCookieEditor(); });
  });

  // ── Persistent Cloud Workspace (backed by the optional RichAF backend) ──
  var cloudSelected = "";
  function setCloudStatus(text, online) {
    var el = document.getElementById("cloud-status"); if (!el) return;
    el.textContent = text; el.className = "backend-status " + (online ? "online" : "offline");
  }
  function cloudList() {
    backendRequest("/api/cloud/list").then(function (data) {
      setCloudStatus("CONNECTED", true);
      var tree = document.getElementById("cloud-tree"); tree.innerHTML = "";
      (data.items || []).forEach(function (item) {
        var row = document.createElement("div"); row.className = "cloud-item";
        row.innerHTML = '<span class="tree-icon material-symbols-rounded">' + (item.type === "folder" ? "folder" : "description") + '</span><span>' + escapeHtml(item.path) + '</span>';
        if (item.type === "file") row.addEventListener("click", function () { cloudOpen(item.path); });
        else row.classList.add("cloud-folder-item");
        tree.appendChild(row);
      });
      if (!data.items || !data.items.length) tree.textContent = "Cloud workspace is empty. Create a folder or file.";
    }).catch(function (err) { setCloudStatus("OFFLINE", false); document.getElementById("cloud-tree").textContent = "Backend unavailable: " + err.message; });
  }
  function cloudOpen(filePath) {
    cloudSelected = filePath;
    document.getElementById("cloud-path").value = filePath;
    document.getElementById("cloud-current").textContent = filePath;
    backendRequest("/api/cloud/file?path=" + encodeURIComponent(filePath)).then(function (data) { document.getElementById("cloud-content").value = data.content || ""; document.getElementById("cloud-status-text").textContent = "Loaded from cloud workspace."; }).catch(function (e) { document.getElementById("cloud-status-text").textContent = e.message; });
  }
  document.getElementById("cloud-refresh").addEventListener("click", cloudList);
  document.getElementById("cloud-folder").addEventListener("click", function () {
    var p = prompt("Folder path", document.getElementById("cloud-path").value || "/new-folder"); if (!p) return;
    backendRequest("/api/cloud/folder", { method: "POST", body: JSON.stringify({ path: p }) }).then(cloudList).catch(function (e) { document.getElementById("cloud-status-text").textContent = e.message; });
  });
  document.getElementById("cloud-file").addEventListener("click", function () {
    var p = prompt("File path", document.getElementById("cloud-path").value || "/new-file.txt"); if (!p) return;
    backendRequest("/api/cloud/file", { method: "PUT", body: JSON.stringify({ path: p, content: "" }) }).then(function () { cloudList(); cloudOpen(p); }).catch(function (e) { document.getElementById("cloud-status-text").textContent = e.message; });
  });
  document.getElementById("cloud-save").addEventListener("click", function () {
    if (!cloudSelected) return;
    backendRequest("/api/cloud/file", { method: "PUT", body: JSON.stringify({ path: cloudSelected, content: document.getElementById("cloud-content").value }) }).then(function () { document.getElementById("cloud-status-text").textContent = "Saved."; cloudList(); }).catch(function (e) { document.getElementById("cloud-status-text").textContent = e.message; });
  });
  document.getElementById("cloud-delete").addEventListener("click", function () {
    if (!cloudSelected) return;
    backendRequest("/api/cloud/item?path=" + encodeURIComponent(cloudSelected), { method: "DELETE" }).then(function () { cloudSelected = ""; document.getElementById("cloud-content").value = ""; document.getElementById("cloud-current").textContent = "No file selected"; cloudList(); }).catch(function (e) { document.getElementById("cloud-status-text").textContent = e.message; });
  });

  // ── Console / CSS / JSON / Settings ─────────────────────────
  document.getElementById("console-run").addEventListener("click", function () {
    var code = document.getElementById("console-input").value;
    var out = document.getElementById("console-out");
    evalPage(
      "(function(){try{return{ok:true,val:(function(){" + code + "})()};}catch(e){return{ok:false,val:e.message};}})()",
      function (result, isException) {
        if (isException) { out.textContent = "ex: " + JSON.stringify(isException); return; }
        if (!result) { out.textContent = "nil"; return; }
        var d = result.val;
        if (typeof d === "object") {
          try { d = JSON.stringify(d, null, 2); } catch (_) { d = String(d); }
        }
        out.textContent = (result.ok ? "" : "ERR: ") + String(d);
      }
    );
  });
  document.getElementById("console-clear-out").addEventListener("click", function () {
    document.getElementById("console-out").textContent = "";
  });

  document.getElementById("css-apply").addEventListener("click", function () {
    evalPage(
      "(function(){var s=document.getElementById('__richaf_css');if(!s){s=document.createElement('style');s.id='__richaf_css';document.head.appendChild(s);}s.textContent='" +
      esc(document.getElementById("css-input").value) + "';})()"
    );
  });
  document.getElementById("css-remove").addEventListener("click", function () {
    evalPage("(function(){var s=document.getElementById('__richaf_css');if(s)s.remove();})()");
  });

  var jsonInput = document.getElementById("json-input");
  var jsonStatus = document.getElementById("json-status");
  function setJsonStatus(msg, ok) {
    jsonStatus.textContent = msg;
    jsonStatus.className = "status-line " + (ok ? "ok" : "err");
  }
  document.getElementById("json-format").addEventListener("click", function () {
    try {
      jsonInput.value = JSON.stringify(JSON.parse(jsonInput.value), null, 2);
      setJsonStatus("ok", true);
    } catch (e) { setJsonStatus(e.message, false); }
  });
  document.getElementById("json-minify").addEventListener("click", function () {
    try {
      jsonInput.value = JSON.stringify(JSON.parse(jsonInput.value));
      setJsonStatus("minified", true);
    } catch (e) { setJsonStatus(e.message, false); }
  });
  document.getElementById("json-copy").addEventListener("click", function () {
    navigator.clipboard.writeText(jsonInput.value).then(function () { setJsonStatus("copied", true); });
  });


  // ── RichAF local backend ───────────────────────────────────
  var backendWs = null;
  var backendTimer = null;

  function backendBase() {
    return String(document.getElementById("server-url")?.value || settings.backendUrl || "http://127.0.0.1:3210").replace(/\/$/, "");
  }

  function setBackendStatus(state, text) {
    var el = document.getElementById("backend-status");
    if (!el) return;
    el.className = "backend-status " + state;
    el.textContent = text || state.toUpperCase();
    // Connection state is intentionally shown only in the Server tab.
    // The global tab-bar indicator was removed to keep navigation clean.
  }

  function backendRequest(path, options) {
    return fetch(backendBase() + path, Object.assign({ headers: { "Content-Type": "application/json" } }, options || {}))
      .then(function (r) { return r.text().then(function (text) { var data; try { data = JSON.parse(text); } catch (_) { data = { raw: text }; } if (!r.ok) throw new Error(data.error || r.statusText || "Backend request failed"); return data; }); });
  }

  function setServerSetupStatus(text, online) {
    var el = document.getElementById("server-setup-status");
    if (!el) return;
    el.textContent = text;
    el.className = "backend-status " + (online ? "online" : "offline");
  }

  function refreshServerSetup() {
    backendRequest("/api/setup/status").then(function (data) {
      setServerSetupStatus(data.initialized ? "READY" : "NOT INITIALIZED", !!data.initialized);
      var out = document.getElementById("server-setup-output");
      if (out) out.textContent = data.initialized ? "Server is initialized and ready for Cloud, saved XHRs, projects, and persistent settings." : "Server is reachable, but its persistent workspace has not been initialized yet.";
    }).catch(function (e) {
      setServerSetupStatus("OFFLINE", false);
      var out = document.getElementById("server-setup-output");
      if (out) out.textContent = "Backend is not reachable. Start the bundled server, then use Initialize server here. " + e.message;
    });
  }

  function copyServerText(text, message) {
    navigator.clipboard.writeText(text).then(function () {
      var out = document.getElementById("server-setup-output");
      if (out) out.textContent = message || "Copied.";
    }).catch(function () {});
  }

  function connectBackend() {
    var url = backendBase();
    settings.backendUrl = url;
    saveSettings();
    setBackendStatus("connecting", "CONNECTING");
    backendRequest("/api/health").then(function (data) {
      setBackendStatus("online", "CONNECTED");
      var out = document.getElementById("server-output");
      if (out) out.textContent = JSON.stringify(data, null, 2);
      if (backendWs) try { backendWs.close(); } catch (_) {}
      try {
        var wsUrl = url.replace(/^http/i, "ws") + "/ws";
        backendWs = new WebSocket(wsUrl);
        backendWs.onopen = function () { var ws = document.getElementById("server-ws"); if (ws) ws.textContent = "CONNECTED"; setBackendStatus("online", "CONNECTED"); };
        backendWs.onclose = function () { var ws = document.getElementById("server-ws"); if (ws) ws.textContent = "DISCONNECTED"; setBackendStatus("offline", "DISCONNECTED"); };
        backendWs.onerror = function () { var ws = document.getElementById("server-ws"); if (ws) ws.textContent = "ERROR"; setBackendStatus("offline", "OFFLINE"); };
        backendWs.onmessage = function (event) {
          try {
            var message = JSON.parse(event.data);
            appendBackendEvent(message);
          } catch (_) {}
        };
      } catch (_) {}
      refreshBackendStatus();
      refreshServerSetup();
      loadApiConnections();
      loadBackendSettings();
      if (backendTimer) clearInterval(backendTimer);
      backendTimer = setInterval(function () { refreshBackendStatus(); }, 5000);
    }).catch(function (err) {
      setBackendStatus("offline", "OFFLINE");
      var out = document.getElementById("server-output");
      if (out) out.textContent = "Backend unavailable. Start backend/server.js with npm install && npm start.\n\n" + err.message;
    });
  }

  function refreshBackendStatus() {
    backendRequest("/api/status").then(function (data) {
      ["clients", "projects", "events"].forEach(function (key) {
        var el = document.getElementById("server-" + key);
        if (el) el.textContent = data[key] == null ? "—" : String(data[key]);
      });
      setBackendStatus("online", "CONNECTED");
      refreshServerSetup();
    }).catch(function () {
      var ws = document.getElementById("server-ws");
      if (ws) ws.textContent = "DISCONNECTED";
      setBackendStatus("offline", "BACKEND DISCONNECTED");
    });
  }

  function apiAuthLabel(auth) {
    return auth === "bearer" ? "Bearer" : auth === "key" ? "API key" : "No auth";
  }

  function renderApiConnections(connections) {
    var list = document.getElementById("api-list");
    if (!list) return;
    if (!connections || !connections.length) { list.innerHTML = '<div class="saved-empty">No API connections yet.</div>'; return; }
    list.innerHTML = connections.map(function (c) {
      return '<div class="api-row" data-api-id="' + esc(String(c.id)) + '">' +
        '<div class="api-row-main"><strong>' + esc(c.name) + '</strong><span>' + esc(c.baseUrl) + '</span></div>' +
        '<span class="api-badge">' + esc(apiAuthLabel(c.auth)) + '</span>' +
        '<div class="api-row-actions"><button class="btn btn-sm api-test" data-id="' + esc(String(c.id)) + '">Test</button><button class="btn btn-sm btn-danger api-delete" data-id="' + esc(String(c.id)) + '">Delete</button></div>' +
      '</div>';
    }).join("");
    list.querySelectorAll(".api-test").forEach(function (btn) {
      btn.addEventListener("click", function () {
        btn.textContent = "Testing…";
        backendRequest("/api/connections/" + encodeURIComponent(btn.dataset.id) + "/test", { method: "POST", body: "{}" }).then(function (data) {
          document.getElementById("server-output").textContent = JSON.stringify(data, null, 2);
          btn.textContent = data.ok ? "OK" : "Failed";
        }).catch(function (e) { document.getElementById("server-output").textContent = e.message; btn.textContent = "Failed"; }).finally(function () { setTimeout(function(){ btn.textContent = "Test"; }, 1800); });
      });
    });
    list.querySelectorAll(".api-delete").forEach(function (btn) {
      btn.addEventListener("click", function () {
        backendRequest("/api/connections/" + encodeURIComponent(btn.dataset.id), { method: "DELETE" }).then(loadApiConnections).catch(function (e) { document.getElementById("server-output").textContent = e.message; });
      });
    });
  }

  function loadApiConnections() {
    backendRequest("/api/connections").then(function (data) { renderApiConnections(data.connections || []); }).catch(function () {});
  }

  function loadBackendSettings() {
    backendRequest("/api/backend/settings").then(function (data) {
      var x = data.settings || {};
      if (document.getElementById("backend-host")) document.getElementById("backend-host").value = x.host || "127.0.0.1";
      if (document.getElementById("backend-port")) document.getElementById("backend-port").value = x.port || 3210;
      if (document.getElementById("backend-heartbeat")) document.getElementById("backend-heartbeat").value = x.heartbeat || 10;
      if (document.getElementById("backend-cors")) document.getElementById("backend-cors").value = x.cors || "*";
      if (document.getElementById("backend-body")) document.getElementById("backend-body").value = x.bodyLimitMb || 2;
      if (document.getElementById("backend-ws-mode")) document.getElementById("backend-ws-mode").value = x.websocket === false ? "disabled" : "enabled";
    }).catch(function () {});
  }

  function appendBackendEvent(event) {
    var out = document.getElementById("tool-events");
    if (!out) return;
    var line = "[" + new Date(event.timestamp || Date.now()).toLocaleTimeString() + "] " + (event.type || "event") + " " + JSON.stringify(event.payload || {});
    var lines = (out.textContent === "No backend events yet." ? [] : out.textContent.split("\n")).filter(Boolean);
    lines.unshift(line);
    out.textContent = lines.slice(0, 80).join("\n");
  }

  function loadBackendConfig() {
    backendRequest("/api/config").then(function (data) {
      if (!data.settings) return;
      if (data.settings.background) settings.background = data.settings.background;
      if (data.settings.backgroundBlur != null) settings.backgroundBlur = Number(data.settings.backgroundBlur) || 0;
      if (data.settings.backgroundDim != null) settings.backgroundDim = Number(data.settings.backgroundDim) || 25;
      applyBackground();
    }).catch(function () {});
  }

  function applyBackground() {
    var url = settings.background || "";
    document.documentElement.style.setProperty("--richaf-bg-image", url ? 'url("' + String(url).replace(/"/g, '\\"') + '")' : "none");
    document.documentElement.style.setProperty("--richaf-bg-blur", (Number(settings.backgroundBlur) || 0) + "px");
    document.documentElement.style.setProperty("--richaf-bg-dim", String(Math.max(0, Math.min(100, Number(settings.backgroundDim) || 0)) / 100));
    document.body.classList.toggle("has-bg", !!url);
    var blur = document.getElementById("set-bg-blur");
    var dim = document.getElementById("set-bg-dim");
    var blurVal = document.getElementById("set-bg-blur-val");
    var dimVal = document.getElementById("set-bg-dim-val");
    if (blur) blur.value = Number(settings.backgroundBlur) || 0;
    if (dim) dim.value = Number(settings.backgroundDim) || 25;
    if (blurVal) blurVal.textContent = (Number(settings.backgroundBlur) || 0) + "px";
    if (dimVal) dimVal.textContent = (Number(settings.backgroundDim) || 25) + "%";
    var bgUrl = document.getElementById("set-bg-url");
    if (bgUrl && document.activeElement !== bgUrl) bgUrl.value = url;
  }

  function saveBackendConfig() {
    return backendRequest("/api/config", { method: "PUT", body: JSON.stringify({ background: settings.background, backgroundBlur: settings.backgroundBlur, backgroundDim: settings.backgroundDim }) }).catch(function () {});
  }

  function uploadBackground(file) {
    if (!file) return;
    var form = new FormData();
    form.append("background", file);
    fetch(backendBase() + "/api/backgrounds/upload", { method: "POST", body: form }).then(function (r) { return r.json(); }).then(function (data) {
      if (!data.ok) throw new Error(data.error || "Upload failed");
      settings.background = data.url;
      saveSettings();
      applyBackground();
    }).catch(function (err) {
      setBackendStatus("offline", "UPLOAD FAILED");
      var out = document.getElementById("server-output"); if (out) out.textContent = err.message;
    });
  }

  document.getElementById("server-setup-init").addEventListener("click", function () {
    var out = document.getElementById("server-setup-output");
    if (out) out.textContent = "Initializing RichAF server…";
    backendRequest("/api/setup", { method: "POST", body: "{}" }).then(function (data) {
      setServerSetupStatus("READY", true);
      if (out) out.textContent = data.message || "RichAF server initialized.";
      refreshBackendStatus();
    }).catch(function (e) {
      setServerSetupStatus("OFFLINE", false);
      if (out) out.textContent = "Could not initialize the server: " + e.message;
    });
  });
  document.getElementById("server-copy-install").addEventListener("click", function () {
    copyServerText("cd backend && npm install", "Install command copied. Run it from the RichAF backend folder.");
  });
  document.getElementById("server-copy-start").addEventListener("click", function () {
    copyServerText("cd backend && npm start", "Start command copied. The server will listen on http://127.0.0.1:3210 by default.");
  });
  document.getElementById("server-connect").addEventListener("click", connectBackend);
  document.getElementById("server-ping").addEventListener("click", function () { backendRequest("/api/health").then(function (data) { document.getElementById("server-output").textContent = JSON.stringify(data, null, 2); setBackendStatus("online", "CONNECTED"); refreshServerSetup(); }).catch(function (e) { document.getElementById("server-output").textContent = e.message; setBackendStatus("offline", "OFFLINE"); refreshServerSetup(); }); });
  document.getElementById("server-send").addEventListener("click", function () {
    var message = document.getElementById("server-message").value || "hello RichAF backend";
    backendRequest("/api/events", { method: "POST", body: JSON.stringify({ type: "extension.message", payload: { message: message, page: location.href } }) }).then(function (data) { document.getElementById("server-output").textContent = JSON.stringify(data, null, 2); }).catch(function (e) { document.getElementById("server-output").textContent = e.message; });
  });
  document.getElementById("api-save").addEventListener("click", function () {
    var name = document.getElementById("api-name").value.trim();
    var baseUrl = document.getElementById("api-base").value.trim();
    var auth = document.getElementById("api-auth").value;
    var secret = document.getElementById("api-secret").value;
    var status = document.getElementById("server-output");
    if (!name || !baseUrl) { if (status) status.textContent = "API name and base URL are required."; return; }
    backendRequest("/api/connections", { method: "POST", body: JSON.stringify({ name: name, baseUrl: baseUrl, auth: auth, secret: secret }) }).then(function (data) {
      if (status) status.textContent = "API connected and saved.\n\n" + JSON.stringify(data, null, 2);
      document.getElementById("api-name").value = ""; document.getElementById("api-base").value = ""; document.getElementById("api-secret").value = "";
      loadApiConnections();
    }).catch(function (e) { if (status) status.textContent = e.message; });
  });
  document.getElementById("backend-settings-load").addEventListener("click", loadBackendSettings);
  document.getElementById("backend-settings-save").addEventListener("click", function () {
    var payload = {
      host: document.getElementById("backend-host").value.trim() || "127.0.0.1",
      port: Number(document.getElementById("backend-port").value) || 3210,
      heartbeat: Number(document.getElementById("backend-heartbeat").value) || 10,
      cors: document.getElementById("backend-cors").value,
      bodyLimitMb: Number(document.getElementById("backend-body").value) || 2,
      websocket: document.getElementById("backend-ws-mode").value === "enabled"
    };
    backendRequest("/api/backend/settings", { method: "PUT", body: JSON.stringify(payload) }).then(function () {
      document.getElementById("backend-settings-status").textContent = "Saved. Restart the backend for host/port/body-limit changes to take effect.";
    }).catch(function (e) { document.getElementById("backend-settings-status").textContent = e.message; });
  });
  document.getElementById("tool-page-html").addEventListener("click", function () { evalPage("document.documentElement.outerHTML", function (result) { navigator.clipboard.writeText(String(result || "")).then(function () { document.getElementById("tool-events").textContent = "Page HTML copied to clipboard."; }); }); });
  document.getElementById("tool-copy-resources").addEventListener("click", function () { var urls=[]; Object.keys(hostTree).forEach(function(h){(hostTree[h]||[]).forEach(function(f){urls.push(f.url||f.path);});}); navigator.clipboard.writeText(urls.join("\n")).then(function(){document.getElementById("tool-events").textContent="Resource URLs copied.";}); });
  document.getElementById("tool-dom-stats").addEventListener("click", refreshPageInfo);
  document.getElementById("tool-clear-events").addEventListener("click", function () { backendRequest("/api/events", { method: "DELETE" }).then(function () { document.getElementById("tool-events").textContent="Backend events cleared."; }); });
  document.getElementById("set-bg-apply").addEventListener("click", function () { settings.background = document.getElementById("set-bg-url").value.trim(); settings.backgroundBlur = Number(document.getElementById("set-bg-blur").value) || 0; settings.backgroundDim = Number(document.getElementById("set-bg-dim").value) || 25; saveSettings(); applyBackground(); saveBackendConfig(); });
  document.getElementById("set-bg-clear").addEventListener("click", function () { settings.background = ""; saveSettings(); applyBackground(); backendRequest("/api/backgrounds", { method: "DELETE" }).catch(function(){}); });
  document.getElementById("set-bg-file").addEventListener("change", function () { uploadBackground(this.files && this.files[0]); });
  document.getElementById("set-bg-blur").addEventListener("input", function () { settings.backgroundBlur = Number(this.value); applyBackground(); });
  document.getElementById("set-bg-dim").addEventListener("input", function () { settings.backgroundDim = Number(this.value); applyBackground(); });

  function loadSettings() {
    chrome.storage.local.get(["richaf_settings"], function (data) {
      if (data.richaf_settings) settings = Object.assign(settings, data.richaf_settings);
      document.getElementById("set-refresh").value = settings.autoRefresh || 0;
      document.getElementById("set-css").value = settings.savedCss || "";
      document.getElementById("set-outline").checked = settings.outlineOnLoad !== false;
      if (document.getElementById("set-font")) document.getElementById("set-font").value = "Arial";
      settings.font = "Arial";
      if (document.getElementById("set-glass")) document.getElementById("set-glass").checked = settings.glass !== false;
      if (document.getElementById("set-animations")) document.getElementById("set-animations").checked = settings.animations !== false;
      applyInterfacePreferences();
      if (settings.savedCss) document.getElementById("css-input").value = settings.savedCss;
      if (document.getElementById("server-url")) document.getElementById("server-url").value = settings.backendUrl || "http://127.0.0.1:3210";
      applyAutoRefresh();
      applyBackground();
      connectBackend();
      loadBackendConfig();
    });
  }
  function saveSettings() { chrome.storage.local.set({ richaf_settings: settings }); }
  function applyAutoRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    var sec = parseInt(settings.autoRefresh, 10) || 0;
    if (sec > 0) refreshTimer = setInterval(refreshPageInfo, sec * 1000);
  }
  document.getElementById("set-refresh").addEventListener("change", function () {
    settings.autoRefresh = parseInt(document.getElementById("set-refresh").value, 10) || 0;
    saveSettings();
    applyAutoRefresh();
  });
  document.getElementById("set-css-save").addEventListener("click", function () {
    settings.savedCss = document.getElementById("set-css").value;
    saveSettings();
    document.getElementById("css-input").value = settings.savedCss;
  });
  document.getElementById("set-outline").addEventListener("change", function () {
    settings.outlineOnLoad = document.getElementById("set-outline").checked;
    saveSettings();
  });

  document.getElementById("set-font").addEventListener("change", function () {
    settings.font = this.value;
    saveSettings();
    applyInterfacePreferences();
  });
  document.getElementById("set-glass").addEventListener("change", function () {
    settings.glass = this.checked;
    saveSettings();
    applyInterfacePreferences();
  });
  document.getElementById("set-animations").addEventListener("change", function () {
    settings.animations = this.checked;
    saveSettings();
    applyInterfacePreferences();
  });

  // Boot screen gets a small pause so the glass/fade treatment is visible.
  setTimeout(finishBoot, 180);

  loadSettings();
  loadRealSources();
})();
