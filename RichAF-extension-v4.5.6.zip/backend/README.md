# RichAF Backend

Local Node.js backend for the RichAF DevTools extension.

## Start

1. Install Node.js 18+.
2. Open a terminal in this `backend` folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open RichAF DevTools. The Server tab should show `CONNECTED`.

Default address: `http://127.0.0.1:3210`

Environment variables:

- `RICHAF_PORT=3210`
- `RICHAF_HOST=127.0.0.1`

The backend stores settings/projects/events in `backend/data/richaf.json` and uploaded backgrounds in `backend/uploads/backgrounds`.
