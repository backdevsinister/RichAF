const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const http = require('http');
const { WebSocketServer } = require('ws');

const PORT = Number(process.env.RICHAF_PORT || 3210);
const HOST = process.env.RICHAF_HOST || '127.0.0.1';
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(ROOT, 'uploads', 'backgrounds');
const DATA_FILE = path.join(DATA_DIR, 'richaf.json');
const CLOUD_DIR = path.join(DATA_DIR, 'cloud');
fs.mkdirSync(CLOUD_DIR, { recursive: true });

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const defaultStore = {
  settings: {
    theme: 'dark',
    accent: '#39ff14',
    background: '',
    backgroundBlur: 0,
    backgroundDim: 0.25
  },
  backendSettings: { host: HOST, port: PORT, heartbeat: 10, cors: '*', bodyLimitMb: 2, websocket: true },
  apiConnections: [],
  projects: [],
  events: []
};

function loadStore() {
  try {
    return Object.assign({}, defaultStore, JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')));
  } catch (_) {
    return JSON.parse(JSON.stringify(defaultStore));
  }
}

let store = loadStore();
function saveStore() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2));
}

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

app.use(cors({ origin: true }));
app.use(express.json({ limit: '2mb' }));
app.use('/backgrounds', express.static(UPLOAD_DIR));

const upload = multer({
  storage: multer.diskStorage({
    destination: (_, __, cb) => cb(null, UPLOAD_DIR),
    filename: (_, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase().slice(0, 12) || '.bin';
      const safe = path.basename(file.originalname, path.extname(file.originalname))
        .replace(/[^a-z0-9_-]/gi, '_').slice(0, 48) || 'background';
      cb(null, `${Date.now()}-${safe}${ext}`);
    }
  }),
  limits: { fileSize: 12 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    cb(null, /^image\/(png|jpeg|webp|gif|avif)$/i.test(file.mimetype));
  }
});

function broadcast(type, payload) {
  const message = JSON.stringify({ type, payload, timestamp: Date.now() });
  wss.clients.forEach(client => {
    if (client.readyState === 1) client.send(message);
  });
}

function addEvent(type, payload) {
  store.events.unshift({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, type, payload, timestamp: Date.now() });
  store.events = store.events.slice(0, 100);
  saveStore();
  broadcast(type, payload);
}


function safeCloudPath(input) {
  const raw = String(input || '/').replace(/\\/g, '/');
  const normalized = path.posix.normalize('/' + raw.replace(/^\/+/, ''));
  if (normalized === '/..' || normalized.startsWith('/../')) throw new Error('Invalid cloud path');
  const relative = normalized.replace(/^\/+/, '');
  const absolute = path.resolve(CLOUD_DIR, relative);
  const root = path.resolve(CLOUD_DIR);
  if (absolute !== root && !absolute.startsWith(root + path.sep)) throw new Error('Invalid cloud path');
  return { normalized, absolute };
}
function cloudWalk(dir, prefix, out) {
  for (const name of fs.readdirSync(dir, { withFileTypes: true })) {
    const absolute = path.join(dir, name.name);
    const rel = (prefix + '/' + name.name).replace(/\/+/g, '/');
    if (name.isDirectory()) { out.push({ type: 'folder', path: rel }); cloudWalk(absolute, rel, out); }
    else out.push({ type: 'file', path: rel, size: fs.statSync(absolute).size });
  }
}

app.get('/api/cloud/list', (_req, res) => {
  const items = [];
  cloudWalk(CLOUD_DIR, '', items);
  items.sort((a, b) => a.path.localeCompare(b.path));
  res.json({ ok: true, items });
});

app.post('/api/cloud/folder', (req, res) => {
  try {
    const target = safeCloudPath(req.body?.path);
    fs.mkdirSync(target.absolute, { recursive: true });
    addEvent('cloud.folder.created', { path: target.normalized });
    res.status(201).json({ ok: true, path: target.normalized });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});

app.get('/api/cloud/file', (req, res) => {
  try {
    const target = safeCloudPath(req.query.path);
    if (!fs.existsSync(target.absolute) || !fs.statSync(target.absolute).isFile()) return res.status(404).json({ ok: false, error: 'File not found' });
    res.json({ ok: true, path: target.normalized, content: fs.readFileSync(target.absolute, 'utf8') });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});

app.put('/api/cloud/file', (req, res) => {
  try {
    const target = safeCloudPath(req.body?.path);
    if (target.normalized === '/') throw new Error('A file needs a name');
    fs.mkdirSync(path.dirname(target.absolute), { recursive: true });
    fs.writeFileSync(target.absolute, String(req.body?.content ?? ''), 'utf8');
    addEvent('cloud.file.saved', { path: target.normalized });
    res.json({ ok: true, path: target.normalized });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});

app.delete('/api/cloud/item', (req, res) => {
  try {
    const target = safeCloudPath(req.query.path);
    if (target.normalized === '/') throw new Error('Cannot delete cloud root');
    if (!fs.existsSync(target.absolute)) return res.status(404).json({ ok: false, error: 'Item not found' });
    fs.rmSync(target.absolute, { recursive: true, force: true });
    addEvent('cloud.item.deleted', { path: target.normalized });
    res.json({ ok: true });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});

app.get('/api/setup/status', (_req, res) => {
  res.json({
    ok: true,
    initialized: fs.existsSync(DATA_FILE),
    dataDirectory: fs.existsSync(DATA_DIR),
    cloudDirectory: fs.existsSync(CLOUD_DIR),
    uploadDirectory: fs.existsSync(UPLOAD_DIR),
    backend: { host: HOST, port: PORT, version: '4.5.6' }
  });
});

app.post('/api/setup', (_req, res) => {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.mkdirSync(CLOUD_DIR, { recursive: true });
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
    if (!fs.existsSync(DATA_FILE)) {
      store = loadStore();
      saveStore();
    }
    addEvent('server.initialized', { dataDirectory: DATA_DIR, cloudDirectory: CLOUD_DIR });
    res.json({ ok: true, initialized: true, message: 'RichAF server initialized.' });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, name: 'RichAF Backend', version: '4.5.6', port: PORT, uptime: process.uptime(), websocket: true });
});

app.get('/api/config', (_req, res) => {
  res.json({ settings: store.settings, backend: { host: HOST, port: PORT, websocket: true } });
});

app.put('/api/config', (req, res) => {
  store.settings = Object.assign({}, store.settings, req.body || {});
  saveStore();
  addEvent('config.updated', store.settings);
  res.json({ ok: true, settings: store.settings });
});

app.get('/api/backend/settings', (_req, res) => {
  res.json({ ok: true, settings: store.backendSettings || { host: HOST, port: PORT, heartbeat: 10, cors: '*', bodyLimitMb: 2, websocket: true } });
});

app.put('/api/backend/settings', (req, res) => {
  const current = store.backendSettings || {};
  const next = Object.assign({}, current, req.body || {});
  next.host = String(next.host || HOST).slice(0, 120);
  next.port = Math.max(1, Math.min(65535, Number(next.port || PORT)));
  next.heartbeat = Math.max(2, Math.min(120, Number(next.heartbeat || 10)));
  next.cors = next.cors === 'same-origin' ? 'same-origin' : '*';
  next.bodyLimitMb = Math.max(1, Math.min(50, Number(next.bodyLimitMb || 2)));
  next.websocket = next.websocket !== false;
  store.backendSettings = next;
  saveStore();
  addEvent('backend.settings.updated', { ...next });
  res.json({ ok: true, settings: next, restartRequired: true });
});

app.get('/api/connections', (_req, res) => {
  const connections = (store.apiConnections || []).map(c => ({ id: c.id, name: c.name, baseUrl: c.baseUrl, auth: c.auth, createdAt: c.createdAt, updatedAt: c.updatedAt }));
  res.json({ ok: true, connections });
});

app.post('/api/connections', (req, res) => {
  const name = String(req.body?.name || '').trim().slice(0, 80);
  const baseUrl = String(req.body?.baseUrl || '').trim().replace(/\/$/, '');
  const auth = req.body?.auth === 'bearer' || req.body?.auth === 'key' ? req.body.auth : 'none';
  const secret = String(req.body?.secret || '');
  try { new URL(baseUrl); } catch (_) { return res.status(400).json({ ok: false, error: 'Enter a valid API base URL.' }); }
  if (!name) return res.status(400).json({ ok: false, error: 'API name is required.' });
  if (!store.apiConnections) store.apiConnections = [];
  const connection = { id: `api-${Date.now()}-${Math.random().toString(36).slice(2,7)}`, name, baseUrl, auth, secret, createdAt: Date.now(), updatedAt: Date.now() };
  store.apiConnections.push(connection);
  saveStore();
  addEvent('api.connection.created', { id: connection.id, name, baseUrl, auth });
  res.status(201).json({ ok: true, connection: { id: connection.id, name, baseUrl, auth, createdAt: connection.createdAt, updatedAt: connection.updatedAt } });
});

app.put('/api/connections/:id', (req, res) => {
  const connection = (store.apiConnections || []).find(c => c.id === req.params.id);
  if (!connection) return res.status(404).json({ ok: false, error: 'API connection not found.' });
  if (req.body?.name != null) connection.name = String(req.body.name).trim().slice(0, 80);
  if (req.body?.baseUrl != null) { try { const u = new URL(String(req.body.baseUrl).trim()); connection.baseUrl = u.toString().replace(/\/$/, ''); } catch (_) { return res.status(400).json({ ok: false, error: 'Invalid API URL.' }); } }
  if (req.body?.auth != null) connection.auth = req.body.auth === 'bearer' || req.body.auth === 'key' ? req.body.auth : 'none';
  if (req.body?.secret != null) connection.secret = String(req.body.secret);
  connection.updatedAt = Date.now();
  saveStore();
  addEvent('api.connection.updated', { id: connection.id, name: connection.name, baseUrl: connection.baseUrl, auth: connection.auth });
  res.json({ ok: true, connection: { id: connection.id, name: connection.name, baseUrl: connection.baseUrl, auth: connection.auth, updatedAt: connection.updatedAt } });
});

app.delete('/api/connections/:id', (req, res) => {
  const before = (store.apiConnections || []).length;
  store.apiConnections = (store.apiConnections || []).filter(c => c.id !== req.params.id);
  saveStore();
  addEvent('api.connection.deleted', { id: req.params.id });
  res.json({ ok: true, deleted: store.apiConnections.length !== before });
});

app.post('/api/connections/:id/test', async (req, res) => {
  const connection = (store.apiConnections || []).find(c => c.id === req.params.id);
  if (!connection) return res.status(404).json({ ok: false, error: 'API connection not found.' });
  const headers = { 'User-Agent': 'RichAF-Backend/4.5.6' };
  if (connection.auth === 'bearer' && connection.secret) headers.Authorization = `Bearer ${connection.secret}`;
  if (connection.auth === 'key' && connection.secret) headers['X-API-Key'] = connection.secret;
  const started = Date.now();
  try {
    const response = await fetch(connection.baseUrl, { method: 'GET', headers, redirect: 'follow', signal: AbortSignal.timeout(8000) });
    const text = await response.text();
    res.json({ ok: response.ok, status: response.status, statusText: response.statusText, ms: Date.now() - started, preview: text.slice(0, 500) });
  } catch (e) {
    res.status(502).json({ ok: false, error: e.message, ms: Date.now() - started });
  }
});

app.get('/api/projects', (_req, res) => res.json({ projects: store.projects }));

app.post('/api/projects', (req, res) => {
  const project = {
    id: `project-${Date.now()}`,
    name: String(req.body?.name || 'Untitled Project').slice(0, 100),
    path: String(req.body?.path || '').slice(0, 500),
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  store.projects.push(project);
  saveStore();
  addEvent('project.created', project);
  res.status(201).json({ ok: true, project });
});

app.delete('/api/projects/:id', (req, res) => {
  const before = store.projects.length;
  store.projects = store.projects.filter(p => p.id !== req.params.id);
  saveStore();
  res.json({ ok: store.projects.length !== before });
});

app.get('/api/events', (_req, res) => res.json({ events: store.events }));

app.post('/api/events', (req, res) => {
  const type = String(req.body?.type || 'extension.event').slice(0, 80);
  const payload = req.body?.payload ?? null;
  addEvent(type, payload);
  res.status(201).json({ ok: true });
});

app.delete('/api/events', (_req, res) => {
  store.events = [];
  saveStore();
  broadcast('events.cleared', {});
  res.json({ ok: true });
});

app.post('/api/backgrounds/upload', upload.single('background'), (req, res) => {
  if (!req.file) return res.status(400).json({ ok: false, error: 'Upload a PNG, JPEG, WEBP, GIF, or AVIF image.' });
  const url = `/backgrounds/${encodeURIComponent(req.file.filename)}`;
  const absolute = `http://${HOST}:${PORT}${url}`;
  store.settings.background = absolute;
  saveStore();
  addEvent('background.uploaded', { url: absolute, filename: req.file.filename });
  res.status(201).json({ ok: true, url: absolute });
});

app.delete('/api/backgrounds', (_req, res) => {
  store.settings.background = '';
  saveStore();
  addEvent('background.cleared', {});
  res.json({ ok: true });
});

app.get('/api/status', (_req, res) => {
  res.json({ ok: true, clients: wss.clients.size, events: store.events.length, projects: store.projects.length });
});

wss.on('connection', socket => {
  socket.send(JSON.stringify({ type: 'hello', payload: { name: 'RichAF Backend', version: '4.5.6' }, timestamp: Date.now() }));
  socket.on('message', raw => {
    try {
      const message = JSON.parse(String(raw));
      if (message.type === 'ping') socket.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
    } catch (_) {}
  });
});

app.get('/', (_req, res) => {
  res.type('html').send(`<!doctype html><html><head><meta charset="utf-8"><title>RichAF Backend</title><style>body{font-family:system-ui;background:#0a0a0a;color:#ddd;padding:40px}code{color:#39ff14}</style></head><body><h1>RichAF Backend</h1><p>Backend is running.</p><p><code>GET /api/health</code></p><p><code>WebSocket /ws</code></p></body></html>`);
});

server.listen(PORT, HOST, () => {
  console.log(`RichAF backend listening on http://${HOST}:${PORT}`);
});
